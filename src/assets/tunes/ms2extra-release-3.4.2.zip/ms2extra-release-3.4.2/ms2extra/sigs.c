/* $Id: sigs.c,v 1.496 2016/04/21 10:53:08 jsmcortina Exp $
 * Copyright 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013
 * James Murray and Kenneth Culver
 *
 * This file is a part of MS2/Extra.
 *
 * You should have received a copy of the code LICENSE along with this source,
 * ask on the www.msextra.com forum if you did not.
 *
 */

#include "ms2_extra.h"
const char RevNum[SIZE_OF_REVNUM] =  {    /* revision no:
    This is the internal serial format, don't expose to user.
    Only change for interface change, leave last letter alone. */
#ifdef MSPNP2
  "MS2Extra comms342aP" /* MSPNP2 #3 */
#elif defined(MICROSQUIRTMODULE)
  "MS2Extra comms342aM" /* Microsquirt module #2 */
#elif defined(MICROSQUIRT)
  "MS2Extra comms342aU" /* Microsquirt #1 */
#else
  "MS2Extra comms342a2" /* MS2 #0 */
#endif
//"1234567890123456789"
},
 Signature[SIZE_OF_SIGNATURE] = {            /* program title.
    This is the code version, change this every time you tweak a feature.
    This should be shown to the user. */
  "MS2/Extra 3.4.2 release  20160421 11:50BST(c)KC/JSM/JB   "
/*"123456789012345678901234567890123456789012345678901234567"*/
 },
/* Do not edit these, for display only and not really needed any more. */
#ifdef MSPNP2
Platform[4] = "PNP";
#elif defined(MICROSQUIRTMODULE)
Platform[4] = "uSM";
#elif defined(MICROSQUIRT)
Platform[4] = " uS";
#else
Platform[4] = "MS2";
#endif

