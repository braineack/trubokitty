/* $Id: sigs.c,v 1.2 2007/05/03 23:16:20 jsmcortina Exp $ */
const char RevNum[20] =  {    // revision no:
 // only change for major rev and/or interface change.
  "MS2Extra Rev ***** "
},
 Signature[32] = {            // program title.
 // Change this every time you tweak a feature.
  "MS2/Extra Loader 02 May 2007 ***"
 };
