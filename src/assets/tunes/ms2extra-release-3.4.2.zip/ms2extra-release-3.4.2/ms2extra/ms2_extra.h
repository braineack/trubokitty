/* $Id: ms2_extra.h,v 1.303 2016/01/19 23:29:17 jsmcortina Exp $
 * Copyright 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013
 * James Murray and Kenneth Culver
 *
 * This file is a part of MS2/Extra.
 *
 * You should have received a copy of the code LICENSE along with this source,
 * ask on the www.msextra.com forum if you did not.
 *
 */

/* This header should be included by all other source files in the
 * ms2-extra project.
 */

#ifndef _MS2_EXTRA_H
#define _MS2_EXTRA_H

#include "hcs12def.h"      /* common defines and macros */
#include "flash.h"         /* flashburner defines, structures */
#include <string.h>

#include "us_opt_c.h"

#include "ms2_extra_defines.h" /* generated from #define list in ms2_extra_vars.h */

extern void _start(void);       /* Startup routine */

//#define CAN_TEST

#define FAR_TEXT3c_ATTR __attribute__ ((far)) __attribute__ ((section (".text3c")))
#define FAR_TEXT3d_ATTR __attribute__ ((far)) __attribute__ ((section (".text3d")))
#define FAR_TEXT38_ATTR __attribute__ ((far)) __attribute__ ((section (".text38")))
#define FAR_TEXT39_ATTR __attribute__ ((far)) __attribute__ ((section (".text39")))
#define FAR_TEXT3a_ATTR __attribute__ ((far)) __attribute__ ((section (".text3a")))
#define FAR_TEXT3b_ATTR __attribute__ ((far)) __attribute__ ((section (".text3b")))
#define LOOKUP_ATTR __attribute__ ((section (".lookup")))
#define EEPROM_ATTR __attribute__ ((section (".eeprom")))
#define TEXT3a_ATTR __attribute__ ((section (".text3a")))
#define TEXT3_ATTR __attribute__ ((section (".text3")))
#define INTERRUPT
#define POST_INTERRUPT __attribute__((interrupt))
#define POST_INTERRUPT_TEXT3 __attribute__ ((section (".text3"))) __attribute__((interrupt))
#define POST_INTERRUPT_TEXT3d __attribute__ ((section (".text3d"))) __attribute__((interrupt))
#define ENABLE_INTERRUPTS __asm__ __volatile__ ("cli");
#define DISABLE_INTERRUPTS __asm__ __volatile__ ("sei");
/* These next two require "unsigned char maskint_tmp, maskint_tmp2" in function */
#define MASK_INTERRUPTS __asm__ __volatile__ ("stab %0\n" "tfr ccr,b\n" "stab %1\n" "ldab %0\n" "sei\n" : :"m"(maskint_tmp),"m"(maskint_tmp2) ); /* Must be used with RESTORE */
#define RESTORE_INTERRUPTS __asm__ __volatile__ ("stab %0\n" "ldab %1\n" "tfr b,ccr\n" "ldab %0\n" : :"m"(maskint_tmp),"m"(maskint_tmp2) ); /* Must be used with MASK */
#define NEAR
#define VECT_ATTR __attribute__ ((section (".vectors")))

INTERRUPT void UnimplementedISR(void) POST_INTERRUPT;
INTERRUPT void ISR_Ign_TimerIn(void) POST_INTERRUPT_TEXT3;
INTERRUPT void ISR_Ign_TimerIn_paged(void) FAR_TEXT38_ATTR;
INTERRUPT void ISR_Ign_TimerOut(void) POST_INTERRUPT;
INTERRUPT void ISR_TC5(void) POST_INTERRUPT_TEXT3;
INTERRUPT void ISR_Dwl_TimerOut(void) POST_INTERRUPT;
INTERRUPT void ISR_Rot_TimerOut(void) POST_INTERRUPT;
INTERRUPT void ISR_Rot_SpkTimerOut(void) POST_INTERRUPT;
INTERRUPT void ISR_Inj1_TimerOut(void) POST_INTERRUPT_TEXT3;
INTERRUPT void ISR_Inj2_TimerOut(void) POST_INTERRUPT_TEXT3;
void ISR_Inj3_TimerOut(void) POST_INTERRUPT_TEXT3;
void ISR_Inj4_TimerOut(void) POST_INTERRUPT_TEXT3;
INTERRUPT void ISR_TimerOverflow(void) POST_INTERRUPT;
INTERRUPT void ISR_Timer_Clock(void) POST_INTERRUPT;
INTERRUPT void ISR_SCI_Comm(void) POST_INTERRUPT;
INTERRUPT void CanTxIsr(void) POST_INTERRUPT_TEXT3;
INTERRUPT void CanRxIsr(void) POST_INTERRUPT_TEXT3;

typedef void (* NEAR tIsrFunc)(void);

int intrp_1dctable(int x, unsigned char n, int * x_table, char sgn,
		unsigned char * z_table);
int intrp_1dctableu(unsigned int x, unsigned char n, int * x_table, char sgn,
		unsigned char * z_table);
int intrp_1ditable(int x, unsigned char n, int *x_table, char sgn,
		unsigned int *z_table);
int intrp_2dctable(unsigned int x, int y, unsigned char nx, unsigned char ny,
		unsigned int * x_table, int * y_table, unsigned char * z_table,
		unsigned char hires);
int intrp_2dctable_signed(unsigned int x, int y, unsigned char nx,
		unsigned char ny, unsigned int * x_table, int * y_table,
		char * z_table);
int intrp_2ditable(unsigned int x, int y, unsigned char nx, unsigned char ny,
		unsigned int * x_table, int * y_table, int * z_table);
unsigned int twoptlookup(unsigned int x, unsigned int x0, unsigned int x1, unsigned int y0, unsigned int y1 ) FAR_TEXT3c_ATTR;

typedef struct {
   unsigned int *addrRam;
   unsigned int *addrFlash;
   unsigned int  n_bytes;
} tableDescriptor;

extern const tableDescriptor tables[NO_TBLES];

// User inputs - 1 set in flash, 1 in ram
typedef struct {
    unsigned char no_cyl,no_skip_pulses,      // skip >= n pulses at startup
                  ICIgnOption,     // Bit 0: Input capture: 0 = falling edge, 1 rising
                  // bit 3: 0 = evenfire, 1 = oddfire
                  // bit 4 = spk out hi/lo 0 = spk low (gnd)
                  // bit 5 = inj2 uses own parameters

                  injctl2,
                  max_coil_dur,max_spk_dur,xDurAcc;        // ms x 15 (10* 3/2)
    unsigned char deltV_table[NO_COILCHG_PTS],deltDur_table[NO_COILCHG_PTS], // Vx10,%age/2
     PredOpt;          // Option for prediction algorithm for next tach plse
    //  0=use last time interval
    //  1=use 1st deriv prediction; 2=use 1st deriv at hi
    //   rpm, 2nd deriv prediction at lo rpm;
    //  3=use 2nd deriv prediction always.
    unsigned int crank_rpm;        // rpm at which cranking is through (~300 - 400 rpm)
    int cold_adv_table[NO_TEMPS],
        adv_offset,        // all in deg x 10
        //     adv_offset is no deg(x10) between trigger (Input Capture) and TDC.
        //     It may be +btdc (IC1 to TDC) or -atdc (TDC to IC2).
        //
        //    |               |     |
        //    |               |     |
        //   -|---------------|-----|-
        //   IC1             TDC    IC2
        TpsBypassCLTRevlim, RevLimNormal2_hyst;
    //    to RevLimMaxRtd at Rpm2
    // Optn 2:Cut fuel above Rpm2, restore below Rpm1
    unsigned char afr_table[NO_INJ][NO_FMAPS][NO_FRPMS],            // afr x 10
                  warmen_table[NO_TEMPS], // % enrichment vs temp
                  tpsen_table[NO_TPS_DOTS], // accel enrichment pw in .1 ms units vs tpsdot
                  mapen_table[NO_MAP_DOTS]; // accel enrichment pw in .1 ms units vs mapdot
    int iacstep_table[NO_TEMPS]; // iac steps vs temp
    unsigned int frpm_tablea[NO_INJ][NO_FRPMS];  // fuel, spk rpm tables
    int fmap_tablea[NO_INJ][NO_FMAPS],      // kpa x 10,
        temp_table[NO_TEMPS],             // deg x 10 (C or F)
        tpsdot_table[NO_TPS_DOTS],        // change in % x 10 per .1 sec
        mapdot_table[NO_MAP_DOTS];        // change in kPa x 10 per .1 sec
    int map0,mapmax,clt0,cltmult,mat0,matmult,tps0,tpsmax,batt0,battmax,
        // kPa x 10, deg F or C x 10, adc counts, volts x 10
        ego0,egomult,baro0,baromax,bcor0,bcormult,knock0,knockmax;
    // afr x 10, kpa x 10, volts x 100
    int Dtpred_Gain;  // %
    unsigned char CrnkTol,ASTol,PulseTol,   // % tolerance for next input pulse
                  // timing during cranking, after start/warmup and normal running
                  IdleCtl,         // Changed from 2013-08-29. 0 = none
                  IACtstep,        // iac stepper motor nominal time between steps (.1 ms units)
                  IAC_tinitial_step, // Moving only initial step delay after valve powerup. 
                  IACminstep,     // iac stepper motor no. of accel/decel steps - future use
                  dwellduty;       // dwell duty%
    int IACStart,     // no. of steps to send at startup to put stepper
        //    motor at reference (wide open) position
        IdleHyst,        // amount clt temp must move before Idle position is changed
        IACcrankpos,     // IAC pos must be open(<) at least this much(steps) in cranking
        IACcrankxt;      // no. seconds from end of cranking for IAC pos to blend into coolant dependent pos.
    unsigned char IACcurlim;
    unsigned char iacspare[5];
    unsigned int InjOpen,BatFac;
    unsigned char OverBoostOption;
    int OverBoostKpa;
    int OverBoostHyst;
    unsigned char xoverboostcutx, xoverboostcuty;
    unsigned char secondtrigopts;
#define NOISE_FILTER_ONLY 0x1
    int TpsThresh, MapThresh;
    unsigned char  Tpsacold,     // cold (-40F) accel amount in .1 ms units
                   AccMult;         // cold (-40F) accel multiply factor (%)
    int mapsample_angle;
    unsigned char  TpsAsync,        // clock duration (in .1 sec tics) for accel enrichment
                   TPSDQ;           // deceleration fuel cut option (%)
    int TPSWOT,       // TPS value at WOT (for flood clear) in %x10
        TPSOXLimit;      // Max tps value (%x10) where O2 closed loop active
    unsigned char Tps_acc_wght,    // weight (0-100) to be given to tpsdot for accel enrichment.
                  //  100 - Tps_acc_wght will then be given to mapdot.
                  BaroOption,      // 0=no baro, 1=baro is 1st reading of map (before cranking), (baroCorr)
                  // 2=independent barometer (=> EgoOption not 2 or 4)
                  EgoOption,       // 0 = no ego;1= nb o2;2=2 nb o2;3=single wbo2;4=dual wbo2. NOTE:
                  //  BaroOption MUST be < 2 if EgoOption = 2 or 4.
                  EgoCountCmp,     // Ign Pulse counts between when EGO corrections are made
                  EgoStep,         // % step change for EGO corrections
                  oldEgoLimit,        // Upper/Lower rail limit (egocorr inside 100 +/- limit)
                  AFRTarget,       // NBO2 AFR determining rich/ lean
                  Temp_Units,      // 0= coolant & mat in deg F; 1= deg C
                  MAFOption,mapsample_opt; // MAF options
    int FastIdle,     // fast idle Off temperature (idle_ctl = 1 only)
        EgoTemp;         // min clt temp where ego active
    unsigned int RPMOXLimit;      // Min rpm where O2 closed loop is active
    unsigned int ReqFuel;     // fuel pulsewidth (usec) at wide open throttle
    unsigned char Divider,    // divide factor for input tach pulses
                  Alternate,       // option to alternate injector banks. bit 0 normal function, bit 1 means /2 during crank
                  dummy2,         // Injector open time (.1 ms units)
                  InjPWMTim,       // Time (.1 ms units) after Inj opening to start pwm
                  InjPWMPd,        // Inj PWM period (us) - keep between 10-25 KHz (100-40 us)
                  InjPWMDty,       // Inj PWM duty cycle (%)
                  dummy1,          // Battery fuel pw correction factor (msx10)
                  EngStroke,       // 0 = 4 stroke
                  // 1 = 2 stroke
                  InjType,         // 0 = port injection
                  // 1 = throttle body
                  NoInj;           // no. of injectors (1-12)
unsigned int      OddFireang;        //  smaller angle bet firings (deg*10)
unsigned char     rpmLF,mapLF,tpsLF,   // Lag filter coefficient for Rpm,Map,Tps. Acts like
                  egoLF,           // averager: xnew = xold + xLF * (xmeas - xold), so xLF=0
                  adcLF,knkLF,     // means value will never change, xLF=100 means no filtering.
                  // egoLF is coefficient for ego filter, adcLF is for clt,mat,batt,
                  // knkLF is for knock.
                  mafLF,       // same for MAF
                  dual_tble_optn,  // 1 = use dual table option - ve, afr tables for each inj
                  FuelAlgorithm,       // option for alpha-N mode: 0=none;1=use map,tps blend algorithm;
                  //   2=same as 1, but don't use kpa multiplier in plsewidth eq.
                  //   3=%Baro
                  IgnAlgorithm,        // option to use map,tps(alphaN) blend algorithm for ignition
                  AfrAlgorithm,        // option to use map,tps(alphaN) blend algorithm for WBO2 AFR
                  dwelltime;       // time in 0.1ms
    unsigned int trigret_ang; // angle between trigger and return
    char RevLimOption;     // 0=none, 1=spark retard, 2=fuel cut
    unsigned char RevLimMaxRtd;     // max amount of spark retard (degx10) (at Rpm2 below)
    unsigned char InjPWMTim2,       // Time (.1 ms units) after Inj opening to start pwm
                  InjPWMPd2,        // Inj PWM period (us) - keep between 10-25 KHz (100-40 us)
                  InjPWMDty2;       // Inj PWM duty cycle (%)
    unsigned int  InjOpen2, BatFac2;
    unsigned char mapport;
    int baro_upper, baro_lower, baro_default;
    int RevLimTPSbypassRPM;
    int RevLimRtdAng;
    unsigned int RevLimNormal2;
    unsigned int TC5_required_width;
    int EgoLimit;
    int stoich;
        
        // This goes with the CAN polling for a generic external board
    unsigned char enable_poll;  // bit 0, 1: enable ADC 0-3 and ADC 4-7
                                    // bit 2: enable PWM
                                                                // bit 3: enable digital I/O ports
    unsigned char poll_tables[4];  // Remote table numbers for ADC 0-3, ADC 4-7, PWM and ports data
    unsigned int poll_offset[4];   // Offset in the table (ADC0-3, ADC 4-7, PWM, ports). This assumes that the data is contiguous for each of the 3 data types
    unsigned char ports_dir;            // Bits 0-2: Direction of the 3 remote ports: 0=input, 1=output
                                                                        // Bits 4-6: Set if digital I/Os or single 0-255 value
    unsigned char port_generic;         // Select which port will be used as generic spare port: 0: use MS ports; 1,2,3: Remote ports

    unsigned int enginesize;
	
	unsigned char remotePWMfreq,       // Remote PWM clock frequency  (in MHz)
	              remotePWMprescale;   // Remote PWM clock prescale

    unsigned char can_bcast1, can_bcast2;
    unsigned int can_bcast_int;
    unsigned char feature7, maf_range;
    unsigned int map_phase_thresh;
    unsigned int fuel_pct[2];
    unsigned int flex_baseline;
    unsigned int fuelSpkDel_default;
    unsigned char fuelCorr_default, pad653;
    int boosttol, flexboosttps;
    unsigned int oddfireangs[6];
    unsigned char can_poll_id[4];  // can_poll_id for ADC 0-3, ADC 4-7, PWM and digital I/O ports polling
    unsigned char dummy[9];
    unsigned int  hw_latency;
    unsigned char ego_startdelay;
    unsigned char loadopts;
#define LOADOPTS_FUELMULT 0x01 // 1 mult for fuel, 0 add for fuel
#define LOADOPTS_LOADMULT 0x04 // 1 multiply "load" into final equation, 0 don't
#define LOADOPTS_LOADSTOICH 0x08 // Scale VE by "stoich" value
#define LOADOPTS_OLDBARO 0x40
    unsigned long baud;         // baud rate
    int MAPOXLimit;   // Max map value (kPax10) where O2 closed loop active
    unsigned char board_type,   // board type (1-255) of this board(not used now);
                  // type=0, reserved.
                  // type=1, ECU (MS II)
                  // type=2. Router board
                  // type=3, Generic I/O board
                  // type=4, Transmission Controller, ......
 mycan_id;        // can_id (address) of this board (< MAX_CANBOARDS). Always 0 for ECU.
    unsigned int unused1, unused2, unused3, unused4;
    unsigned char mapsample_window, can_poll, xcan_poll_id0;
#define CAN_POLL_ON 1
        int MAPOXMin ;   // lower map value (kpax10) where 02 closed loop active -- KG  
    char morecrap[1];

    // Generic spare port parameters: spr_port = 0(don't use)/1(use),where
    // spr_port[0-7] = PM2 - PM5; PTT6,7; PORTA0; they are set as outs to main
    //  pcb; out_offset,out_byte= byte offset from start of outpc structure and
    // size in bytes of 1st, 2nd variables to be tested for setting port;
    // condition='<', '>', '=';cond12 = '&','|',' ' connects the conditions for
    // the two variables with ' ' meaning only the first variable condition is
    // desired; thresh = value for the condition(e.g., var1 > thresh1); init_val,
    // port_val=value (0/1) to which the pin will be set at startup and when the
    // condition(s) is met; hyst is a hysteresis delta and works as ff: if a
    // setpoint condition is > and it is met, set port to val and leave until
    // variable is < thresh - hyst, then set pin back to 1 - val. Similarly if
    // condition is <, wait til var > thresh + hyst. For dual conditions, the
    // hysteresis conditions are evaluated the same way, but use the opposite
    // of cond12 to connect them (if cnd12 is &, use | and vice versa).
    char
        spr_port   [NPORT], // NPORT == 7
                   condition1 [NPORT],
                   condition2 [NPORT],
                   cond12     [NPORT],
                   init_val   [NPORT],
                   port_val   [NPORT];
    unsigned char  out_byte1  [NPORT],
                   out_byte2  [NPORT];
    unsigned int
        out_offset1[NPORT],
        out_offset2[NPORT];
    int thresh1    [NPORT],
        thresh2    [NPORT],
        hyst1      [NPORT],
        hyst2      [NPORT];
    unsigned char
        TpsAsync2,  // accel tailoff duration (sec x 10)
        primedelay;
    int
        TpsAccel2;      // end pulsewidth of accel enrichment (ms x 10)
    unsigned char
        EgoAlg, // 0=simple prop error algorithm;
        // 1=same algorithm with variable transport delay;
        // 2=full PID with Smith Pred correction.
        egoKP,
        egoKI,
        egoKD;    // PID coefficients in %; egoKP also gain for
    // EgoAlg=0, with 100 = no gain; egoKD includes
    // 1/dt factor since fixed time step.
    unsigned int
        egoKdly1, // coefficients used to calculate ego transport
        egoKdly2;      // delay (ms) = Kdly1 + Kdly2*120000 / (map(kPax10)*rpm)
    unsigned char
        FlexFuel, // Flex fuel option - modifies pw and spk adv based on % alcohol.
        fuelFreq[2],      // Table of fuel sensor freq(Hz) vs %fuel corr;
        fuelCorr[2],
        dwellmode; // dwell mode
    unsigned int iacfullopen;
    char dummy3[10];
    unsigned char
        xxCWOption,        // Cold warmup option - 0 = linear, 1 = custom table.
        knk_option,      // Bits 0-1: 0=no knock detection;1=operate at table value or 1
        // step below knock; 2=operate at table value or edge of knock.
		// Bit 2: local port 0=AD7/JS4, 1=AD6/JS5
		// Bit 3: 0=local or 1=remote
        // Bits 4-7: 0/1 = knock signal < or > knk_thresh indicates knock occurred.
        knk_maxrtd,      // max total retard when knock occurs, (degx10),
        knk_step1,knk_step2, // ign retard/ adv steps when 1st knock or after stopped,
        // (degx10); step1 large to quickly retard/ stop knock
        knk_trtd,knk_tadv,   // time between knock retard, adv corrections, (secx10);
        // allows short time step to quickly retard, longer to try advancing.
        knk_dtble_adv, // change in table advance required to restart adv til knock or
        // reach table value (0 knock retard) process, deg x10.
        // This only applies with knk_option = 1.
        knk_ndet,    // number knock detects required for valid detection; pad byte.
        EAEOption;   // Bits 0-1: 1: on or off, 2: Use lag compensation
    int knk_maxmap;        // no knock retard above this map (kPax10).
    unsigned int
        knk_lorpm,knk_hirpm,  // no knock retard below, above these rpms.
        knk_rpm[NO_KNKRPMS],  // tables of rpm vs knock threshhold(Vx100).
        knk_thresh[NO_KNKRPMS],
        No_Teeth;          // Nominal (include missing) teeth for wheel decoding
    unsigned char
        No_Miss_Teeth;     // Number of consecutive missing teeth.
    unsigned int
        Miss_ang;     // Position of missing tooth BTDC deg*10
    unsigned char
        ICISR_tmask,                            // Time (msx10) after tach input capture during which further
        // interrupts are inhibited to mask coil ring or VR noise.
        ICISR_pmask,                            // % of dtpred after tach input capture during which further
        // interrupts are inhibited to mask coil ring or VR noise.
        // This and prior mask not applicable with wheel decoding.
        knkport;
    unsigned int
        ae_lorpm,ae_hirpm; // lorpm is rpm at which normal accel enrichment just starts
    // to scale down, and is reduced to 0 at ae_hirpm. To omit scaling, set _lorpm
    // = _hirpm= very large number.
    int
        ffSpkDel[2];      // Table of fuel sensor freq(Hz) vs spk corr (degx10);
    unsigned char IC2ISR_tmask;
    unsigned char IC2ISR_pmask;
    unsigned char NoiseFilterOpts;
    unsigned char extra_load_opts; /* bit 0-1: afrload: 0 = use fuelload, 1 = MAP, 2 = % baro, 3 = TPS */
                                   /* bit 2-3: eaeload: 0 = use fuelload, 1 = MAP, 2 = % baro, 3 = TPS */
     unsigned char
        spk_config_spka, // config byte
        spk_conf2, // various see ini
        spk_config,    // config byte
        // bit0 sparkA 0=JS6 (MS2 default) 1= D14 (MS1/Extra default)
        // when num_spk_op > 3 always D14 as JS6 = sparkD
        // bit1 0=360deg 1=720
        // bit3,2 = 0 invalid, 1 = missing crank, 2 = 2nd trig, 3 = both
        // bit5,4 = 0 invalid, 1 rising, 2 falling, 3 rising&falling
        spk_mode,      // defines standard/EDIS/toothed wheel
        spk_mode3,     // num/type of coils
        rtbaroport,    // defines AD port used for RT baro 2nd sensor, MS2/GPIO
        //AD ports bottom three bits are AD0-7, upper bits
        // 0 = MS2, 1= GPIO1, 2=GPIO2
        ego2port,      // defines AD port used for 2nd EGO sensor MS2/GPIO
        egoport;       // defines port used for first EGO sensor: 0 means local port; > 0 means remote CAN port
#define SPKCONF2_KICK 0x40
    unsigned int kickdelay; /* Kickstart late spark */
        unsigned char
        xrevlimcuty,
        feature4_0;      // various settings
#define SPK_CONF2_GMBYPASS 1
    //bit 0 = simple/advanced false trigger protection when userlevel>191
    //bit 1 = enable middle LED as ignition trigger. Certain modes prevent this.
    //bit 7 = enable logging of VANOS position. Tooth no. -> status4, time diff -> istatus5 
    int pwmidle_table[NO_TEMPS];  // 10 pwm
    unsigned char timing_flags, crank_dwell;
    int crank_timing, fixed_timing;
#define TIMING_FIXED 0x1
#define USE_PREDICTION 0x2
} page4_data;

#define PWMIDLE_NUM_BINS 8

typedef struct {
    unsigned int pwmidle_target_rpms[PWMIDLE_NUM_BINS];
    int pwmidle_clt_temps[PWMIDLE_NUM_BINS];
    unsigned int  pwmidle_ms;
    unsigned char pwmidle_close_delay;
    unsigned char pwmidle_open_duty,
                  pwmidle_closed_duty, pwmidle_pid_wait_timer, pwmidle_min_duty;
    unsigned int XXpwmidle_engage_rpm_adder;
    int pwmidle_tps_thresh;
    unsigned char pwmidle_dp_adder;
    int pwmidle_rpmdot_threshold, pwmidle_decelload_threshold;
    unsigned int pwmidle_Kp, pwmidle_Ki, pwmidle_Kd;
    unsigned char pwmidle_freq;   // 1 = 30.5 Hz, 2 = 61 Hz, etc...
#define PWMIDLE_FREQ_CL_DISPLAY_PID 0x80
    unsigned int pwmidle_min_rpm, pwmidle_max_rpm;
    unsigned char pwmidle_targ_ramptime;
    int pwmidle_rpmdot_disablepid;
    unsigned char pwmidle_port;  // 0: local; 1,2,3: remote port number
    unsigned char pwmidle_dp_decay_factor;
    int boost_ctl_sensitivity;
    unsigned char junk[1];  // was 4
    unsigned char boost_ctl_settings;  // bit 0-2: freq-divider
                                       // bit 3: on or off
                                       // bit 4: closed loop?
                                       // bit 5: invert?
                                       // bit 6: remote
                                       // bit 7: basic or advanced mode?
#define BOOST_CTL_ON            0x8
#define BOOST_CTL_CLOSED_LOOP   0x10
#define BOOST_CTL_INVERT        0x20
#define BOOST_CTL_REMOTE        0x40
#define BOOST_CTL_ADVANCED_MODE 0x80
    unsigned char boost_ctl_pins;  // Bits 4-5: remote port number
#define BOOST_CTL_IACA 0x1
#define BOOST_CTL_IACB 0x2
#define BOOST_CTL_JS11 0x4
#define BOOST_CTL_IDLE 0x8
#define BOOST_CTL_PINS_USE_INITIAL 0x40
    unsigned char boost_ctl_Kp, boost_ctl_Ki, boost_ctl_Kd, boost_ctl_closeduty, boost_ctl_openduty;
    unsigned int boost_ctl_ms;
    int boost_ctl_load_targets[8][8];
    int boost_ctl_loadtarg_tps_bins[8];
    unsigned int boost_ctl_loadtarg_rpm_bins[8];
    unsigned char boost_ctl_pwm_targets[8][8];
    int boost_ctl_pwmtarg_tps_bins[8];
    unsigned int boost_ctl_pwmtarg_rpm_bins[8];
    unsigned int pwmidle_crank_dutyorsteps[4];
    int pwmidle_crank_clt_temps[4];
        int inj_adv_table3[6][6];       // injection advance table for single pulse in siamese sequential mode
    unsigned int srpm_inj_adv3[6];  // injection advance rpm tables     
    int smap_inj_adv3[6];           // kpa x 10,        
//    char junk1[134]; //was 230
    int               // this is primePWtable, CrankPctTable, asePctTable, aseCntTable
        CWPrime[NO_TEMPS],CrankPctTable[NO_TEMPS],CWAWEV[NO_TEMPS],CWAWC[NO_TEMPS];
    int
        MatTemps[NO_MAT_TEMPS];  // MAT temperatures for spark retard, degx10 F or C
    unsigned char
        MatSpkRtd[NO_MAT_TEMPS]; // degx10 of spark retard vs mfld air temp
    unsigned int
        EAEAWCRPMbins[NO_FRPMS],
        EAESOCRPMbins[NO_FRPMS],
        EAEAWCKPAbins[NO_FMAPS], /* MAP bins for EAE */
        EAESOCKPAbins[NO_FMAPS];
    unsigned char
        EAEBAWC[12], /* Added to the Wall coefficient */
        EAEBSOC[12], /* sucking off the wall coefficient */
        EAEAWN[12], /* added to the walls rpm scalar */
        EAESON[12], /* pulled from walls rpm scalar */
        EAEAWW[12], /* added to the walls CLT scalar */
        EAESOW[12]; /* pulled from the walls CLT scalar */
    int MatVals[NO_MAFMATS];       // air temperatures (degx10) for air density correction table. Old version.
    int AirCorDel[NO_MAFMATS];     // Air density corrections (+/-%) - added to eq. value. Old version.
    int boost_ctl_lowerlimit;
    char pad728[10];
    // to correct for varying mat sensor location
    int temp_table_p5[NO_TEMPS];
    unsigned int tsf_rpm;
    int tsf_kpa, tsf_tps;
    unsigned int tss_rpm;
    int tss_kpa, tss_tps;  // table switch
    int EAEAWWCLTbins[12], EAESOWCLTbins[12];
    unsigned char airden_scaling;
    unsigned char ts_port;  // fuel and spark port selection
    unsigned char
        feature5_0,  // on/off feature settings
        //bitval 1 = overrun fuel cut
        XXpwmidlecoldpc, // not used
        pwmidlecranking,
        pwmidlecranktaper,
        pwmidleset;   // settings bits 0 = 78Hz, 156Hz   1 = normal, inverse output
    unsigned int fc_rpm;
    int fc_kpa, fc_tps, fc_clt; // overrun fuel cut >rpm, <kpa, >tps, >clt
    unsigned char fc_delay;  // > time in 0.1s units
    unsigned char tacho_opt; // tacho output option
    unsigned char EAElagsource; // 0 = tpsdot, 1 = MAPdot
    int EAElagthresh;
    unsigned int EAElagRPMmax;
    unsigned char fc_ego_delay;
    unsigned int fc_rpm_lower;
    unsigned int pwmidle_shift_lower_rpm;
    unsigned char pwmidle_shift_open_time;
    unsigned char morepage5[10];
    char
        rmt_spr_port   [8],
        rmt_condition1 [8],
        rmt_condition2 [8],
        rmt_cond12     [8],
        rmt_init_val   [8],
        rmt_port_val   [8];
    unsigned char rmt_out_byte1  [8],
        rmt_out_byte2  [8];
    unsigned int
        rmt_out_offset1[8],
        rmt_out_offset2[8];
    int    rmt_thresh1    [8],
        rmt_thresh2    [8],
        rmt_hyst1      [8],
        rmt_hyst2      [8];
} page5_data;

typedef struct {
    int
        adv_table[2][NO_SMAPS][NO_SRPMS]; // two spark tables
    unsigned int srpm_table[2][NO_SRPMS];  // fuel, spk rpm tables
    int smap_table[2][NO_SMAPS];            // kpa x 10,
    unsigned char feature3,  // feature settings (presently only ASM vs C ign_out ISR)
                    // 0x2 Use MAP lag lookup based on TPSdot
             launch_opt; //launch/flat shift options
    unsigned int launch_sft_zone;
    int launch_sft_deg;
    unsigned int launch_hrd_lim;
    int launch_tps;
    unsigned char launchlimopt, // launch limiter options
                  xlaunchcutx,
                  xlaunchcuty;
    unsigned int flats_arm, xflats_sft; // flat shift options
    int flats_deg;
    unsigned int flats_hrd;

    unsigned int staged_pri_size, staged_sec_size;
    unsigned char staged;  /* Bits 0-2: 000 = off, 001 = RPM, 010 = MAP, 011 = TPS, 100 = Duty, 101 = Table
                            * Bits 3-5: second param: 00 = off, 01 = rpm, 10 = MAP, 11 = TPS, 100 = Duty, 101 = Table
                            * Bit 6: transition on
                            * Bit 7: 2nd param: 0 = OR logic, 1 = AND logic
                            */
    unsigned char staged_transition_events;
    int staged_param_1, staged_param_2;
    int staged_hyst_1, staged_hyst_2;

// Nitrous System
    unsigned char N2Oopt;    // bit 0-1: DT bank usage
                             // bit 2: stage 1 enable
                             // bit 3: stage 2 enable
                             // bits 4-6: input pin
    unsigned int N2ORpm, N2ORpmMax;
    signed int  N2OTps, N2OClt, N2OAngle;
    unsigned int N2OPWLo, N2OPWHi;
    unsigned char N2Odel_launch, N2Odel_flat, N2Oholdon;
    unsigned int N2O2Rpm, N2O2RpmMax;
    unsigned char N2O2delay;
    signed int N2O2Angle;
    unsigned int N2O2PWLo, N2O2PWHi;

/* user defined */
    unsigned int user_value1;
    unsigned int user_value2;
    unsigned char user_conf;
/* end user defined */

    unsigned int staged_secondary_enrichment;
    unsigned char staged_percents[6][6];
    unsigned int staged_rpms[6];
    int staged_loads[6];
    unsigned char N2Oopt_pins;  //local/remote pinports for nitrous in and out
    unsigned char crap8[2];
    unsigned char dwelltime_trl;
    int RotarySplitTable[8][8];
    unsigned int RotarySplitMAP[8];
    unsigned int RotarySplitRPM[8];
    unsigned char RotarySplitMode;
#define ROTARY_SPLIT_FD_MODE 0x1
#define ROTARY_SPLIT_ALLOW_NEG_SPLIT 0x2
#define ROTARY_SPLIT_RX8_MODE 0x4
    unsigned int NoiseFilterRpm[4];
    unsigned int NoiseFilterLen[4];
    unsigned char padnfo;
    unsigned char staged_primary_delay;
    unsigned char VariableLagTPSBins[4];
    unsigned char VariableLagMapLags[4];
// test options for semi sequential
    unsigned char crap_ss[9];
    unsigned char trig_init;
    unsigned char inj_time_mask;
    char crap7[19]; // was 30
} page10_data;

typedef struct {
    unsigned char pwm_testio, duty_testio;
    unsigned char testcoil,     // which coil to fire
        testdwell;              // dwell in 0.1ms
    unsigned int testint; // interval in 0.128ms units
    unsigned int testpw, testinjcnt;
    unsigned char testsel;
    int adv_table3[NO_SMAPS][NO_SRPMS]; // two spark tables
    unsigned int srpm_table3[NO_SRPMS];  // fuel, spk rpm tables
    int smap_table3[NO_SMAPS];      // kpa x 10,
    unsigned char     testInjPWMTim,       // Time (.1 ms units) after Inj opening to start pwm
                      testInjPWMPd,        // Inj PWM period (us) - keep between 10-25 KHz (100-40 us)
                      testInjPWMDty;       // Inj PWM duty cycle (%)
#define REVLIMRPMSIZE 8
    unsigned int RevLimLookup[REVLIMRPMSIZE],RevLimRpm1[REVLIMRPMSIZE];
    unsigned int iacpostest; // test word. Fix iac postion. 0 = off
    unsigned int iachometest; // test home position
    unsigned char flashlock;
    unsigned char idle_special_ops; // right now, just idle advance, but possibly idle VE and other idle-only features later
    int idleadvance_tps;
    unsigned int idleadvance_rpm;
    int idleadvance_load;
    int idleadvance_clt;
    unsigned char idleadvance_delay;
#define IDLE_SPECIAL_OPS_IDLEADVANCE_LOAD       0x01
#define IDLE_SPECIAL_OPS_IDLEADVANCE_RPM        0x02
#define IDLE_SPECIAL_OPS_IDLEADVANCE_ADAPTIVE   0x04
#define IDLE_SPECIAL_OPS_IDLEADVANCE_ADDER      0x08
#define IDLE_SPECIAL_OPS_IDLEADVANCE_CL_COND    0x10

    unsigned char junk[16];
    unsigned char feature413;

        unsigned char crapalign;
        // Siamese and sequential injection     
        unsigned char seq_inj;  // Bit 0: 1 = Sequential        
                                                        // Bit 1: 1 = Siamese   
                                                        // Bit 2: 1 = Extra injector drivers    
                                                        // Bit 3: 0 = Single timing value; 1 = Dual timing values       
                                                        // Bit 4: 0 = Don't use VE trim tables; 1 = Use VE trim tables  
                                                        // Bit 5: 0 = Fixed timing; 1 = Use table       
                                                        // Bit 6,7: 0 = Start-of-pulse; 1 = Mid-pulse; 2 = End-of-pulse 
        int inj_adv_fixed[6];   // Fixed injection advance: advance 1, advance 2, advance 3, staged advance 1, staged advance 2, staged advance 3       
        int inj_adv_table[2][6][6];     
    unsigned int srpm_inj_adv[2][6];  // injection advance rpm tables   
    int smap_inj_adv[2][6];         // kpa x 10,        
        int inj_adv_crank[2];   // Injection advance for cranking 1 and 2
        unsigned int hybrid_rpm, hybrid_hyst;   // Hybrid mode: RPM and hysteresis
    unsigned int InjOpen3,BatFac3,InjOpen4,BatFac4;
        
    union {
        char ve_trim1L[NO_EXFMAPS][NO_EXFRPMS];
        char ve_trim1S[NO_FMAPS][NO_FRPMS];
    } ve_tables;
    union {
        unsigned int frpm_trimvL[NO_EXFRPMS];
        unsigned int frpm_trimvS[NO_FRPMS];
    } frpm_tables;
    union {
        int fmap_trimvL[NO_EXFMAPS];            // kpa x 10,
        int fmap_trimvS[NO_FMAPS];
    } fmap_tables;
    unsigned int can_outpc_msg;
    unsigned char can_outpc_gp[32]; /* omit unused groups */
    unsigned char spare989[34];
} page8_data;

typedef struct {
    union {
        unsigned char ve_tableL[3][NO_EXFMAPS][NO_EXFRPMS];
        unsigned char ve_tableS[3][NO_FMAPS][NO_FRPMS];
    } ve_tables;
    union {
        unsigned int frpm_tablevL[3][NO_EXFRPMS];  // 2x fuel rpm tables
        unsigned int frpm_tablevS[3][NO_FRPMS];
    } frpm_tables;
    union {
        int fmap_tablevL[3][NO_EXFMAPS];            // kpa x 10,
        int fmap_tablevS[3][NO_FMAPS];
    } fmap_tables;
    unsigned int MAFFlow[12];
    unsigned char MAFCor[12];
    unsigned int matclt_pct[6];
    unsigned int matclt_flow[6];
    char junk[4];
} page9_data;

typedef struct {
    union {
        char ve_trimL[3][NO_EXFMAPS][NO_EXFRPMS];
        char ve_trimS[3][NO_FMAPS][NO_FRPMS];
    } ve_tables;
    union {
        unsigned int frpm_trimvL[3][NO_EXFRPMS];
        unsigned int frpm_trimvS[3][NO_FRPMS];
    } frpm_tables;
    union {
        int fmap_trimvL[3][NO_EXFMAPS];            // kpa x 10,
        int fmap_trimvS[3][NO_FMAPS];
    } fmap_tables;
    int ITB_load_loadvals[10];
    int ITB_load_switchpoints[10];
    unsigned int ITB_load_rpms[10];
    char junk[4];
} page11_data;  

#define OUTMSG_SIZE 16
#define OUTMSG_NB   8
typedef struct {
    unsigned int offset[OUTMSG_SIZE];  // Offset of the variable in outpc
    unsigned char size[OUTMSG_SIZE];   // Size of the variables
} outmsg;

typedef struct {
    unsigned char count; /* Byte counter */
    unsigned char id; /* Dest ID */
    unsigned char tab; /* Dest table */
    unsigned char off; /* Dest offset */
} outmsg_stat;

typedef struct {
    // idle up section --------------------------------------------------------------------
    unsigned char idle_up_options;  // 0
    #define IDLE_UP_OPTIONS_ON 0x40
    #define IDLE_UP_OPTIONS_INV 0x80
    unsigned char ac_idleup_adder;  // 1
    unsigned int ac_idleup_cl_targetadder; // 2
    unsigned int ac_idleup_delay; // 4
    unsigned char ClutchPIDEntry; // 6
    unsigned char pidrpm_window; // 7

    unsigned char ac_idleup_io_out; //8
    unsigned char pwmidle_cl_opts;  // 9
    #define PWMIDLE_CL_USE_INITVALUETABLE 0x1 
    #define PWMIDLE_CL_INITVAL_CLT 0x2

    signed int idleadvance_curve[5];  // 10
    signed int idleadvance_loads[5];  // 20
    signed int idleadvance_rpms[5]; // 30
    signed int idle_voltage_comp_voltage[6]; // 40
    signed int idle_voltage_comp_delta[6]; // 52

    unsigned int pwmidle_cl_initialvalue_rpms[5]; // 64
    signed int pwmidle_cl_initialvalue_matorclt[5];    // 74
    unsigned char pwmidle_cl_initialvalues[5][5]; // 84

    char spare109;
    unsigned int mafv[64], mafflow[64];

    int BaroVals[NO_BARS],      // Barometric pressures (kPa x 10) for baro correction table
        MatVals[NO_MATS];       // air temperatures (degx10) for air density correction table
    int BaroCorDel[NO_BARS],    // Baro correction correction
         AirCorDel[NO_MATS];     // Air density corrections (+/-%) - added to eq. value
    int tpswot_tps[6];     // Tps values (% x 10) for alpha_map table
    unsigned int tpswot_rpm[6];     // Rpm values for alpha_map table
    unsigned int knock_rpms[10], knock_thresholds[10];

    unsigned char shift_cut_on, shift_cut_in, shift_cut_out, shift_spare;
    unsigned int shift_cut_rpm;
    int shift_cut_tps;
    unsigned char shift_cut_delay, shift_cut_time, shift_cut_soldelay, shift_cut_reshift;
    unsigned int ac_idleup_min_rpm;
    unsigned char ac_delay_since_last_on;
    char junk517;
    unsigned char boost_ctl_cl_pwm_targs1[8][8];
    unsigned int boost_ctl_cl_pwm_rpms1[8];
    int boost_ctl_cl_pwm_targboosts1[8];
    unsigned int can_bcast_user_id;
    unsigned char can_bcast_user_d[8];
    unsigned int dashbcast_id;
    unsigned char dashbcast_opta;
    char junk[13];

    outmsg outmsgs[OUTMSG_NB];  // Up to 8 messages of up to 16 variables each
} page12_data;  

typedef union _ign_time {
    unsigned long time_32_bits;
    unsigned int time_16_bits[2];
} ign_time;

typedef struct _ign_event {
    ign_time            time;           // time after the tooth to fire
    char                tooth;          // the tooth to schedule an event from
    unsigned char       coil;
    char                ftooth;         // "force dwell" tooth
    unsigned char       fs;             // "force spark" flag (only really need a byte)
} ign_event;

typedef struct _fuel_event {
    unsigned int        time;           // time after the tooth to fire using software timer
    char                tooth;          // the tooth to schedule an event from
    unsigned char       inj;
} fuel_event;

typedef struct _map_event {
    unsigned int        time;
    unsigned int        map_window_set;
    char                tooth;
    unsigned char       evnum;
} map_event;

typedef struct _ign_queue {
    unsigned int sel;
    unsigned int time_us;
    unsigned int time_mms;
} ign_queue;

typedef struct {
    unsigned long id;
    unsigned char sz;
    unsigned char action;
    unsigned char data[8];
} can_tx_msg;

/* ignition macros */

#define FIRE_ALL \
    if (flash4.ICIgnOption & 0x10) { \
        if (!(flagbyte11 & FLAGBYTE11_JS10)){ \
            PTM &= ~0x08; \
        } else { \
            PTT &= ~0x20; \
        } \
        if (num_spk > 1) { \
            PTM &= ~0x10; \
        } \
        if (num_spk > 2) { \
            PTM &= ~0x20; \
        } \
        if (num_spk > 3) { \
            PORTA &= ~0x01; \
        } \
        if (num_spk > 4) { \
            PTAD &= ~0x40; \
        } \
        if (num_spk > 5) { \
            PTAD &= ~0x80; \
        } \
    } else { \
        if (!(flagbyte11 & FLAGBYTE11_JS10)) { \
            PTM |= 0x08; \
        } else { \
            PTT |= 0x20; \
        } \
        if (num_spk > 1) { \
            PTM |= 0x10; \
        } \
        if (num_spk > 2) { \
            PTM |= 0x20; \
        } \
        if (num_spk > 3) { \
            PORTA |= 0x01; \
        } \
        if (num_spk > 4) { \
            PTAD |= 0x40; \
        } \
        if (num_spk > 5) { \
            PTAD |= 0x80; \
        } \
    }

#define FIRE_ALL_US \
    if (flash4.ICIgnOption & 0x10) { \
        if (!(flagbyte11 & FLAGBYTE11_JS10)){ \
            PTM |= 0x20; \
        } else { \
            PTT &= ~0x20; \
        } \
        if (num_spk > 1) { \
            PTT &= ~0x10; \
        } \
        if (num_spk > 2) { \
            PTM |= 0x20; \
        } \
        if (num_spk > 3) { \
            PTM |= 0x10; \
        } \
    } else { \
        if (!(flagbyte11 & FLAGBYTE11_JS10)){ \
            PTM &= ~0x20; \
        } else { \
            PTT |= 0x20; \
        } \
        if (num_spk > 1) { \
            PTT |= 0x10; \
        } \
        if (num_spk > 2) { \
            PTM &= ~0x20; \
        } \
        if (num_spk > 3) { \
            PTM &= ~0x10; \
        } \
    }

void SET_COIL(unsigned char*, unsigned char*);

#define COILABIT 0x1
#define COILBBIT 0x2
#define COILCBIT 0x4
#define COILDBIT 0x8
#define COILEBIT 0x10
#define COILFBIT 0x20
#define COILGBIT 0x40 // no outputs connected
#define COILHBIT 0x80 // no outputs connected

#define OUTPUT_LATENCY 6  // known latency in code from outpc compare to bit flipping
#define SPK_TIME_MIN 150 // minimum time after tooth before stepping back

// rs232 Outputs to pc 'outpc'
typedef struct {
unsigned int seconds,pw1,pw2,rpm;           // pw in usec
int adv_deg;                                // adv in deg x 10
volatile unsigned char squirt, engine;
unsigned char afrtgt1, afrtgt2;    // afrtgt in afr x 10
/*
; Squirt Event Scheduling Variables - bit fields for "squirt" variable above
inj1:    equ    0       ; 0 = no squirt; 1 = inj squirting
inj2:    equ    1

; Engine Operating/Status variables - bit fields for "engine" variable above
ready:  equ     0       ; 0 = engine not ready; 1 = ready to run
                                               (fuel pump on or ign plse)
crank:  equ     1       ; 0 = engine not cranking; 1 = engine cranking
startw: equ     2       ; 0 = not in startup warmup; 1 = in startw enrichment
warmup: equ     3       ; 0 = not in warmup; 1 = in warmup
tpsaen: equ     4       ; 0 = not in TPS acceleration mode; 1 = TPS acceleration mode
tpsden: equ     5       ; 0 = not in deacceleration mode; 1 = in deacceleration mode
mapaen: equ     6
mapden: equ     7
*/
#define ENGINE_READY  0x01
#define ENGINE_CRANK  0x02
#define ENGINE_ASE    0x04
#define ENGINE_WUE    0x08
#define ENGINE_TPSACC 0x10
#define ENGINE_TPSDEC 0x20
#define ENGINE_MAPACC 0x40
#define ENGINE_MAPDEC 0x80

unsigned char wbo2_en1,wbo2_en2; // from wbo2 - indicates whether wb afr valid
int baro,map,mat,clt,tps,batt,ego1,ego2;         // baro - kpa x 10
                                                 // map - kpa x 10
                                                 // mat, clt deg(C/F)x 10
                                                 // tps - % x 10
                                                 // batt - vlts x 10
                                                 // ego1,2 - afr x 10
    unsigned int knock;                          // knock - volts x 100
int egocor1,egocor2,aircor,warmcor,                 // all in %
 tpsaccel,tpsfuelcut,barocor,gammae,             // tpsaccel - acc enrich(.1 ms units)
                                                 // tpsfuelcut - %
                                                 // barocor,gammae - %
 vecurr1,vecurr2,iacstep,cold_adv_deg,           // vecurr - %
                                                 // iacstep - steps
                                                 // cold_adv_deg - deg x 10
tpsdot,mapdot;                                   // tps, map rate of change - %x10/.1 sec,
                                                 // kPax10 / .1 sec
unsigned int coil_dur;                           // msx10 coil chge set by ecu
int mafload, fuelload,                           // kpa (=map or tps)
fuelcor;                                         // fuel composition correction - %
unsigned char port_status,                       // Bits indicating spare port status.
  knk_rtd;               // amount of ign retard (degx10) subtracted from normal advance.
unsigned int EAEfcor1;
int egoV1,egoV2;                                                         // ego sensor readbacks in Vx100
volatile unsigned char status1, status2, status3, status4;   // added ms2extra
#define STATUS3_ACOUT 0x80
unsigned int looptime;
unsigned int istatus5;
unsigned int tpsadc; //lets do a real calibration
int fuelload2;
int ignload;
int ignload2;
//int spare[5]; - deleted (base.ini updated)
unsigned char synccnt;
char timing_err;
unsigned long dt3;                               // delta t bet. rpm pulses (us)
unsigned long wallfuel1;
unsigned int gpioadc[8]; // capture values of gpioadc ports
unsigned int gpiopwmin[4];

unsigned int adc6, adc7; // capture values of adc6,7
unsigned long wallfuel2;
unsigned int EAEfcor2;
unsigned char boostduty;
unsigned char syncreason;
/* this variable will hold reasons that trigger wheels lost sync
e.g.
0 = no problem
2 = missing tooth at wrong time
10 = too many teeth before end of sequence
11 = too few teeth before second trigger
12 = too many sync errors
13 = dizzy wrong edge
14 = trigger return vane size
15 = EDIS
16 = EDIS
17 = didn't received the second trigger when expected in wheel mode

space for more common reasons
plus other special reasons for the custom wheels
20 = subaru 6/7 tooth 6 error
21 = subaru 6/7 tooth 3 error
22 = Rover #2 missing tooth error
23 = 420A long tooth not found
24 = 420A cam phase wrong
25 = 420A 
26 = 420A
27 = 420A
28 = 36-1+1
29 = 36-2-2-2 semi sync failed
30 = 36-2-2-2 tooth 14 error
31 = Miata 99-00 - 2 cams not seen
32 = Miata 99-00 - 0 cams seen
33 = 6G72 - tooth 2 error
34 = 6G72 - tooth 4 error
35 = Weber-Marelli
36 = CAS 4/1
37 = 4G63
38 = 4G63
39 = 4G63
40 = Twin trigger
41 = Twin trigger
42 = Chrysler 2.2/2.5
43 = Renix
44 = Suzuki Swift
45 = Vitara
46 = Vitara
47 = Daihatsu 3
48 = Daihatsu 4
49 = VTR1000
50 = Rover #3
51 = GM 7X
52 = 36-2-2-2 tooth 30 error
53 = rc51 semi error
54 = rc51 re-sync error tooth 6
55 = rc51 re-sync error tooth 16
56 = rc51 re-sync error tooth 18
61 = NGC crank pattern
62 = NGC crank pattern
63 = QR25DE
67 = LS1 semi failed
68 = LS1 resync failed
69 = YZF1000 resync failed
70 =61
*/
unsigned int user0; // spare value for the 'user defined'

int inj_adv1, inj_adv2; // injection timing in deg x 10 
unsigned int pw3,pw4;           // pw in usec
int vetrim[4]; 
unsigned int maf;
int eaeload;
int afrload;
int rpmdot;

unsigned char gpioport[3]; // capture values from gpio digi ports (moved to preserve alignment for CAN passthrough)

unsigned char xidleupcnt;
unsigned int cl_idle_targ_rpm;
unsigned int maf_volts;
    int airtemp;
    unsigned int dwell_trl;
    unsigned int fuel_pct;
    int boost_targ;

    int ext_retard;
    int base_advance, idle_cor_advance, mat_retard, flex_advance;
    int adv1, adv2, adv3;
    int revlim_retard, nitrous_retard;
    int deadtime1, n2o_addfuel;
    unsigned char portbde, portam, portt;
    unsigned char can_error_cnt;
    unsigned int can_error;

/* !!! NOTE !!! When adding any additional variables, be sure to adjust
    ochBlockSize in the ini file */
} variables;

typedef struct {
    /* Adj variables. Table = 7, offset = 0, 2, 4, 6. type = S16 */
    int FuelAdj, SpkAdj, IdleAdj, SprAdj; // allow other devices to change our behaviour - AVOID MOVING
    unsigned int testmodelock; // must always be written as 12345 for valid command
    unsigned char testmodemode; // write a 0 to disable, 1 to enable, then 2 etc. for run modes
    unsigned int shutdowncode; /* offset 11 */
} datax;
#define SHUTDOWN_CODE_ACTIVE 0x8501
#define SHUTDOWN_CODESPK_ACTIVE 0x8502
#define SHUTDOWN_CODE_INACTIVE 0x0000

// Prototypes - Note: ISRs prototyped above.
int main(void) FAR_TEXT3d_ATTR; // try 3d to give 16k to play with
void do_spkmode(void) FAR_TEXT3d_ATTR;
void sample_map_tps(char *) FAR_TEXT39_ATTR;
void noisefilter_lookup(void) FAR_TEXT39_ATTR;
void tachmask_calc(void) FAR_TEXT39_ATTR;
void wheel_fill_event_array(ign_event *, ign_event *, int, int,
                             ign_time, unsigned int, unsigned char) FAR_TEXT3b_ATTR;
void wheel_fill_fuel_event_array(fuel_event *, int, ign_time, unsigned int, unsigned char siamese) FAR_TEXT3c_ATTR;
void setup_staging(void) FAR_TEXT3d_ATTR;
void calc_staged_pw(unsigned long, unsigned long) FAR_TEXT3b_ATTR;
unsigned char calc_duty(unsigned long);// FAR_TEXT3d_ATTR;
void staged_on(unsigned long) FAR_TEXT3b_ATTR;
void set_prime_ASE(void) FAR_TEXT39_ATTR;
void set_EAE_lagcomp(void) FAR_TEXT3a_ATTR;
void main_init(void) FAR_TEXT3b_ATTR; // was TEXT3
void ign_reset(void) FAR_TEXT3c_ATTR;
void get_adc(char chan1, char chan2) FAR_TEXT3c_ATTR;
int calc_deadzone_sliding_window(char window, int value, int value_last) FAR_TEXT3c_ATTR;
unsigned int maflookup(unsigned int) FAR_TEXT3c_ATTR;
void calc_rpmdot() FAR_TEXT39_ATTR;
#define ego_get_sample() get_adc(5, 6)
int move_IACmotor(void); // FAR_TEXT3c_ATTR;
int barocor_eq(int baro) FAR_TEXT3c_ATTR;
void set_spr_port(char port, char val) FAR_TEXT3c_ATTR;
int coil_dur_table(int delta_volt) FAR_TEXT3c_ATTR;
int CW_table(int clt, int *table, int *temp_table) FAR_TEXT3c_ATTR;
void CanInit(void) FAR_TEXT3c_ATTR;
unsigned int can_sendburn(unsigned int, unsigned int) FAR_TEXT3c_ATTR;
unsigned int can_reqdata(unsigned int, unsigned int, unsigned int, unsigned char) FAR_TEXT3c_ATTR;
unsigned int can_snddata(unsigned int, unsigned int, unsigned int, unsigned char, unsigned int) FAR_TEXT39_ATTR;
unsigned int can_crc32(unsigned int, unsigned int) FAR_TEXT39_ATTR;
unsigned int can_inc_ring0(void) FAR_TEXT3c_ATTR;
unsigned int can_sndMSG_PROT(unsigned int, unsigned char) FAR_TEXT39_ATTR;
unsigned int can_sndMSG_SPND(unsigned int) FAR_TEXT39_ATTR;
void can_do_tx(void);
unsigned int can_build_msg(unsigned char, unsigned char, unsigned char, unsigned int,
                 unsigned char, unsigned char*, unsigned char) FAR_TEXT39_ATTR;
unsigned int can_build_msg_req(unsigned char, unsigned char, unsigned int, unsigned char,
                 unsigned int, unsigned char) FAR_TEXT39_ATTR;
void can_build_outmsg(unsigned char) TEXT3_ATTR;
void send_can11bit(unsigned int, unsigned char *, unsigned char);
void send_can29bit(unsigned long, unsigned char *, unsigned char);
void can_broadcast(void);
void can_bcast_outpc(unsigned int); /* FAR_TEXT3a_ATTR; */
void can_bcast_outpc_cont(void) FAR_TEXT3d_ATTR;
void cp_page(void) FAR_TEXT39_ATTR;
void can_init_tbl(void) FAR_TEXT3c_ATTR;  // same page as lookup tables
void Flash_Init(void) FAR_TEXT3c_ATTR;
void ign_wheel_init(void) FAR_TEXT3a_ATTR; // was in 3b;
void boost_ctl_init(void) FAR_TEXT3b_ATTR;
void boost_ctl(void) FAR_TEXT3b_ATTR;
void idle_ac_idleup(void) FAR_TEXT38_ATTR;
void idle_ctl_init(void) FAR_TEXT3b_ATTR;
void idle_ctl(void) FAR_TEXT3b_ATTR;
void idle_test_mode(void) FAR_TEXT3b_ATTR;
void idle_on_off(void) FAR_TEXT3b_ATTR;
void idle_iac_warmup(void) FAR_TEXT3b_ATTR;
void idle_pwm_warmup(void) FAR_TEXT39_ATTR;
void idle_closed_loop_calc_dp_decay(void) FAR_TEXT39_ATTR;
void idle_target_lookup(void) FAR_TEXT39_ATTR;
void idle_closed_loop(void) FAR_TEXT39_ATTR;
void idle_closed_loop_throttlepressed(unsigned int) FAR_TEXT39_ATTR;
void idle_closed_loop_throttlelifted(unsigned int, unsigned int) FAR_TEXT39_ATTR;
void idle_closed_loop_pid(unsigned int, unsigned int, char savelast) FAR_TEXT39_ATTR;
int idle_closed_loop_newtarg(unsigned int, unsigned char) FAR_TEXT39_ATTR;
void idle_pwmdithcalc(void) FAR_TEXT3b_ATTR;
void wheel_fill_map_event_array(map_event * map_events_fill, int map_ang,
                                ign_time last_tooth_time,
                                unsigned int last_tooth_ang) FAR_TEXT39_ATTR;
int calc_ITB_load(int percentbaro) FAR_TEXT39_ATTR;
void run_EAE_calcs(void) FAR_TEXT3b_ATTR;

void ego_init(void) FAR_TEXT3c_ATTR;
void ego_get_targs(void) FAR_TEXT3c_ATTR;
void ego_get_targs_gl(void) FAR_TEXT3c_ATTR;
void ego_closed_loop_simple(long *ego1step, long *ego2step) FAR_TEXT3c_ATTR;
void ego_closed_loop_pid(long *ego1step, long *ego2step, unsigned long looptime) FAR_TEXT3c_ATTR;
void ego_closed_loop_pid_dopid(long *egostep, unsigned long looptime, unsigned int ego, unsigned int afrtarg, int ego1or2) FAR_TEXT3c_ATTR;
void ego_calc(void) FAR_TEXT3c_ATTR;
void serial(void) TEXT3_ATTR;
void debug_init() FAR_TEXT3c_ATTR;
void debug_str(unsigned char*) FAR_TEXT3c_ATTR;
void debug_byte(unsigned char) FAR_TEXT3c_ATTR;
void debug_bytehex(unsigned char) FAR_TEXT3c_ATTR;
void debug_bytedec(unsigned char) FAR_TEXT3c_ATTR;
void debug_byte2dec(unsigned char) FAR_TEXT3c_ATTR;
void debug_inthex(unsigned int) FAR_TEXT3c_ATTR;
void debug_longhex(unsigned long) FAR_TEXT3c_ATTR;
void chk_crc(void) FAR_TEXT3c_ATTR; // in same page as calibration tables
void INJ1(void) FAR_TEXT3c_ATTR;
void INJ2(void) FAR_TEXT3c_ATTR;
void INJ3(void) FAR_TEXT3c_ATTR;
void INJ4(void) FAR_TEXT3c_ATTR;
void schedule_fuel(unsigned int TCothis) FAR_TEXT3b_ATTR;
unsigned int add_open(unsigned int pwcalc, unsigned int pw_open) FAR_TEXT3b_ATTR;
void add_vetrim(void) FAR_TEXT3c_ATTR;
long calc_fuel_req_ang (long ang, unsigned long pw, unsigned int pw_open) FAR_TEXT39_ATTR;
void calc_opentime(void) FAR_TEXT39_ATTR;
unsigned char afrLF_calc(long t) FAR_TEXT3c_ATTR;
void user_defined(void) FAR_TEXT3b_ATTR;
void ck_log_clr(void) FAR_TEXT39_ATTR;
void handle_spareports(void) FAR_TEXT39_ATTR;
void handle_ovflo(void) FAR_TEXT39_ATTR;
long long_abs(long) FAR_TEXT39_ATTR;
void sci_baud() FAR_TEXT3d_ATTR;
unsigned int do_testmode(void) FAR_TEXT39_ATTR;
void ckstall(void) FAR_TEXT39_ATTR;
void clear_all(void) FAR_TEXT39_ATTR;
void injpwms(void) FAR_TEXT39_ATTR;
void do_prime(void) FAR_TEXT39_ATTR;
void calc_advance() FAR_TEXT39_ATTR;

// for ASM routines the memory allocation is set in the source file
// *** BUT *** imperative to set the bank here as well or the C code jumps incorrectly.
unsigned long crc32buf(unsigned long, unsigned int, unsigned int) FAR_TEXT3c_ATTR;
void ResetCmd(void) FAR_TEXT3c_ATTR;
void monitor(void) FAR_TEXT3c_ATTR;
void SpSub(void) FAR_TEXT3c_ATTR;
void NoOp(void) FAR_TEXT3c_ATTR;
void burntbl(unsigned int);
unsigned char g_read_copy(unsigned int, unsigned int, unsigned int);
void do_maplog1(void);
void do_maplog2(void);
void do_maplog_rpm(void);
void do_maplog_tooth(void);
// end of ASM

void do_idle(void) FAR_TEXT39_ATTR;

void fire_coil(void);
void dwell_coil_cut(void);

void fire_coil_rotary(void);
void dwell_coil_rotary(void);
void tt2d_sub(void);
void tt2s_sub(void);

void syncfirst(void);
void recheck_syncfirst(void) FAR_TEXT39_ATTR;
void chknewpage(unsigned char);

void do_complog_pri(unsigned long);
void configerror(void) FAR_TEXT3a_ATTR; // real routine in assembly
unsigned int conf_str(void) FAR_TEXT3a_ATTR; // real routine in assembly
unsigned int conf_str_cp(unsigned char*, unsigned int, unsigned int) FAR_TEXT3a_ATTR; // real routine in assembly
void can_poll_remote(void) FAR_TEXT39_ATTR;
void remote_spr_ports(void) FAR_TEXT39_ATTR;
void can_dashbcast(void) FAR_TEXT3a_ATTR;
void tacho_out(void) FAR_TEXT3b_ATTR;
unsigned long muldiv(unsigned int, unsigned long);
void checkforspk(void);
void checkfortimerin(void);
void checkforsci(void);
void calc_flexfuel() FAR_TEXT39_ATTR;

void stack_watch_init(void) FAR_TEXT38_ATTR;
void stack_watch(void) FAR_TEXT38_ATTR;
void shifter(void) FAR_TEXT38_ATTR;

extern const char RevNum[];
extern const char Signature[];
#define SIZE_OF_REVNUM 20
#define SIZE_OF_SIGNATURE 57 // + 3 bytes for MS2/ uS
extern const unsigned char random_no[256];
extern const unsigned int fuelcut_array[4][4];
extern const unsigned char can_outpc_ix[32];
extern const unsigned int can_outpc_int[8];

#include "ms2_extra_vars.h"

#endif
