/* $Id: ms2_extra_ign.c,v 1.153 2016/01/19 22:12:48 jsmcortina Exp $
 * Copyright 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013
 * James Murray and Kenneth Culver
 *
 * This file is a part of MS2/Extra.
 *
 * ign_reset()
    Origin: Al Grippo
    Major: James Murray / Kenneth Culver
    Majority: Al Grippo / James Murray / Kenneth Culver
 * ign_kill
    Origin: James Murray / Kenneth Culver
    Majority: James Murray / Kenneth Culver
 * coil_dur_table
    Origin: Al Grippo
    Majority: Al Grippo
 * wheel_fill_event_array
    Origin: Kenneth Culver
    Moderate: James Murray
    Majority: James Murray / Kenneth Culver
 * syncfirst
    Origin: Kenneth Culver
    Minor: James Murray
    Majority: Kenneth Culver
 * recheck_syncfirst
    Origin: Kenneth Culver
    Minor: Jean Belanger
    Majority: Kenneth Culver
 * do_knock
    Origin: Al Grippo
    Moderate: Add digi inputs. James Murray.
    Majority: Al Grippo / James Murray
 * SET_COIL
    Origin: James Murray / Kenneth Culver
    Majority: James Murray / Kenneth Culver
 * calc_advance
    Origin: Al Grippo
    Major: James Murray / Kenneth Culver
    Majority: Al Grippo / James Murray / Kenneth Culver
 * do_everytooth_calcs
    Origin: Kenneth Culver
    Major: James Murray / Kenneth Culver
    Majority: James Murray / Kenneth Culver
 * do_tach_mask
    Origin: Al Grippo
    Major: Large re-write. James Murray
    Majority: Al Grippo / James Murray
 *
 * You should have received a copy of the code LICENSE along with this source,
 * ask on the www.msextra.com forum if you did not.
 *
*/
#include "ms2_extra.h"

void noisefilter_lookup(void)
{
    unsigned int utmp1;
    if (flash4.NoiseFilterOpts & 0x01) {
        unsigned int noiserpm;
        if (sync_holdoff) {
            noiserpm = sync_holdoff_rpm; /* use prior latched RPM */
        } else if (outpc.rpm < 10) {
            noiserpm = 32767;
        } else {
            noiserpm = outpc.rpm;
        }
        utmp1 = intrp_1ditable(noiserpm,4,(unsigned int *)pg10_ptr->NoiseFilterRpm, 0,
                (unsigned int *)pg10_ptr->NoiseFilterLen);

        NoiseFilterMin = utmp1;
    }
}

void tachmask_calc(void)
{
    unsigned long ltmp1;
    unsigned long tmp_ticks;

    if ((flash4.NoiseFilterOpts & 0x06) || (flash4.secondtrigopts & 0x06)) { // any of the filters/masks enabled?
        tmp_ticks = 25000;
        if (spkmode < 2) {   // EDIS only)
            DISABLE_INTERRUPTS;
            ltmp1 = dtpred;
            ENABLE_INTERRUPTS;
            ltmp1 *= 1000;
        } else { // everything else
            if (ticks_per_deg > 25000) {        // seems to be less than 1000rpm
                tmp_ticks = 25000;      // rail at equiv of 1000, in case we reset/key off etc and need to regain sync
            } else {
                tmp_ticks = ticks_per_deg;
            }

            // a wheel or pseudo wheel. Use smallest tooth angle to determine mask time
            // This percentage (equiv) in here could be made variable like MS2 base's various next pulse tolerance settings

            ltmp1 = tmp_ticks * smallest_tooth_crk;
        }
        ltmp1 *= (unsigned long)flash4.ICISR_pmask;
        ltmp1 /= 100000L;
        ltmp1 += (unsigned long)flash4.ICISR_tmask * 150; 

        if ((flash4.NoiseFilterOpts & 0x02) && (ltmp1 < 65535)) {
            false_period_crk_tix = (unsigned int)ltmp1;
        } else {
            false_period_crk_tix = 0;
        }

        if ((ltmp1 < 576) || (flash4.NoiseFilterOpts & 0x01) || ((flash4.NoiseFilterOpts & 0x04)==0)) { // too short OR crank noise filter OR disabled
            false_mask_crk = 0;
        } else {
            ltmp1 = ltmp1 / 192;
            false_mask_crk = (unsigned int)ltmp1;
        }

        /* No support for EDIS + cam on MS2 */

        ltmp1 = tmp_ticks * smallest_tooth_cam;
        //                    ltmp1 = ltmp1 / 2864; // (equiv to * 35% )
        ltmp1 *= (unsigned long)flash4.IC2ISR_pmask;
        ltmp1 /= 100000L;
        ltmp1 += (unsigned long)flash4.IC2ISR_tmask * 150; 

        if ((flash4.secondtrigopts & 0x02) && (ltmp1 < 65535)) {
            false_period_cam_tix = (unsigned int)ltmp1;
        } else {
            false_period_cam_tix = 0;
        }

        if ((ltmp1 < 576) || (flash4.secondtrigopts & 0x01) || ((flash4.secondtrigopts & 0x04)==0)) { // too short OR cam noise filter OR disabled
            false_mask_cam = 0;
        } else {
            ltmp1 = ltmp1 / 192;
            false_mask_cam = (unsigned int)ltmp1;
        }

    } else {
        false_mask_crk = 0;
        false_mask_cam = 0;
        false_period_crk_tix = 0;
        false_period_cam_tix = 0;
    }            
}

void ign_reset(void)
{
    int a;
    // enter here at init and when in stall condition
    // Disable IC, Ign,Inj OC interrupts
    //    TIE &= 0x94; // may need review
    TIE = 0; // disable all IC/OC ints. Re-enable as required in a mo
    TSCR1 = 0x80;  // always leave timer enabled

    if (outpc.status1 & STATUS1_SYNCOK) { // was synced
        outpc.synccnt++;
        outpc.status1 &= ~(STATUS1_SYNCOK | STATUS1_SYNCLATCH | STATUS1_SYNCFULL);

        /* If we've been running for a bit and somehow lose sync, latch our RPM
            so we can re-use it for noise filters if we re-gain sync quickly */
        if (!(flagbyte2 & flagbyte2_crank_ok)) {
            sync_holdoff_rpm = outpc.rpm;
            sync_holdoff = SYNC_HOLDOFF_TIME;
        }
    }

    // reinitialize
    if (resetholdoff == 0) { // not within burn timeout period
        if (!(conf_err)) {
            PORTE &= ~0x10;   // Turn off fuel Pump.
            outpc.engine = 0;
            outpc.rpm = 0;
        }
        if ((spkmode == 2) && (flash4.spk_conf2 & SPK_CONF2_GMBYPASS)) {
            // Set HEI bypass to 0v - relies on same wiring as main spark output
            if (flash4.ICIgnOption & 0x10) { /* Going high */
#ifdef MICROSQUIRT
                PTT &= ~0x10;
#else
                PTM &= ~0x10;
#endif
            } else { /* Going low */
#ifdef MICROSQUIRT
                PTT |= 0x10;
#else
                PTM |= 0x10;
#endif
            }
        }
        tcrank_done = 0xffff;
        asecount = 0;
        flagbyte2 |= flagbyte2_crank_ok;
    }

    tooth_diff_this = 0;
    tooth_diff_last = 0;
    tooth_diff_last_1 = 0;
    tooth_diff_last_2 = 0;
    pulse_no = 0;  // This will inhibit overflow counters
    t_enable_IC = 0xFFFFFFFF;
    t_enable_IC2 = 0xFFFFFFFF;
    igncount = 0;
    altcount = 0;
    egocount = 0;
    egopstat[0] = egopstat[1] = 0;
    tpsaclk = 0;
    outpc.status3 &= ~STATUS3_CUT_FUEL;
    knk_clk = 0;
    knk_clk_test = flash4.knk_trtd;
    knk_stat = 0;
    knk_count = 0;
    outpc.knk_rtd = 0;
    spark_events = spark_events_a;
    dwell_events = dwell_events_a;
    if ((flash8.seq_inj & 0x03) != 0) {
        fuel1_events = fuel1_events_a;  
        fuel2_events = fuel2_events_a;  
        fuel3_events = fuel3_events_a;  
        fuel4_events = fuel4_events_a;  
    }       

    // Turn off all spark outputs right away
#ifdef MICROSQUIRT
    FIRE_ALL_US;
#else
    FIRE_ALL;
#endif

    // Turn Off injectors
        if (seq_inj_ctrl & SEQ_STD_INJ) {
            TCTL2 &= ~0x44;   // set outputs lo in OL1,3
            CFORC |= 0x0A;
                PWME &= ~0x14;    // turn off pwms
        } else {
#ifdef MICROSQUIRT
            TCTL2 &= ~0x54;   // set outputs lo in OL1,2,3
                TCTL1 &= ~0x01;   // set output lo in OL4
            CFORC |= 0x1E;
#else
            TCTL2 &= ~0x44;   // set outputs lo in OL1,3
                TCTL1 &= ~0xA0;   // set outputs lo in OL6,7
            CFORC |= 0xCA;
#endif
        }
    *pPTMpin3 &= ~0x08;   // turn off inj led
    outpc.squirt = 0;       // injectors off
    IgnOCpinstate = SPK;
    // enable timer & IC interrupt
    synch = SYNC_FIRST;

    dtpred_adder = 0;
    TFLG1 = 0xff; // clear all pending ints
    TIE |= 0x01;
    if (flagbyte5 & FLAGBYTE5_CAM) {
        TIE |= TFLG_trig2;  // enable 2nd trig ISR
        flagbyte1 &= ~flagbyte1_trig2active; // reset software flag
        flagbyte2 &= ~flagbyte2_twintrignow; // reset software flag
    }

    pulse_no = 0;
    dwl[0] = 0; // 0 means not in use
    dwl[1] = 0;
    dwl[2] = 0;
    dwl[3] = 0;
    dwl[4] = 0;
    dwl[5] = 0;
    rdwl[0] = 0; // 0 means not in use
    rdwl[1] = 0;

    trig2cnt = 0;
    tooth_no = 0;
    flagbyte3 &= ~flagbyte3_toothinit;
    flagbyte1 &= ~flagbyte1_trig2active; // clear 2nd trig
    flagbyte22 &= ~FLAGBYTE22_NEW_TOOTH;
    syncerr = 0;
    flagbyte15 &= ~FLAGBYTE15_FIRSTRPM;
    NoiseFilterMin = 0;
    dwell_long = 0;
    dwell_us = 0;
    dwell_us2 = 0;
    last_edge = 255;
    dwellq[0].sel = 0;
    dwellq[1].sel = 0;
    nextcyl_cnt = 0;
    for (a = 0 ; a < no_triggers ; a++) {
        skipdwell[a] = 0; // don't skip this dwell
    }
    skipinj = 0;
    outpc.boostduty = 0;
    return;
}

int coil_dur_table(int delta_volt)
{
    int ix;
    long interp, interp3;
    // returns correction for coil duration vs battery voltage deviation
    //  from 12 V from table lookup in .1 ms units
    // bound input arguments
    if(delta_volt > flash4.deltV_table[NO_COILCHG_PTS-1])  {
        return((int)flash4.deltDur_table[NO_COILCHG_PTS-1]);
    }
    if(delta_volt < flash4.deltV_table[0])  {
        return((int)flash4.deltDur_table[0]);
    }
    // delta_volt in V x 10
    for(ix = NO_COILCHG_PTS - 2; ix > -1; ix--)  {
        if(delta_volt > flash4.deltV_table[ix])  {
            break;
        }
    }
    if(ix < 0)ix = 0;

    interp = flash4.deltV_table[ix + 1] - flash4.deltV_table[ix];
    if(interp != 0)  {
        interp3 = (delta_volt - flash4.deltV_table[ix]);
        interp3 = (100 * interp3);
        interp = interp3 / interp;
        if(interp < 0)interp = 0;
    }
    return((int)(flash4.deltDur_table[ix] +
                interp * (flash4.deltDur_table[ix+1] - flash4.deltDur_table[ix])/ 100));
}

void wheel_fill_event_array(ign_event *spark_events_fill, ign_event *dwell_events_fill,
                            int spk_ang, int dwl_ang, ign_time last_tooth_time,
                            unsigned int last_tooth_ang, unsigned char rotary)
{
    char start, stop, iterate, tth, wfe_err;
    int tth_ang, tmp_ang, i, j;
    ign_time spk_time, dwl_time;
    long tmptime;

    if(rotary) {
        start = 2;
        stop = 4;
    } else {
        start = 0;
        stop = no_triggers;
    }
    for (i = start; i < stop; i++) {
        if (rotary) {
            j = i - 2;
        } else {
            j = i;
        }
        wfe_err = 0;
        iterate = 0;
        tth_ang = trig_angs[j]; // trigger angle for this trigger to allow for oddfire
        tth = trigger_teeth[j];
        while (!iterate) {
            if (tth_ang > spk_ang) {  // must both be signed to get comparison to work
                // found a suitable tooth
                iterate = 1;
            } else {
                //how far do we step back in deg
                tth--;
                if (tth < 1) {
                    tth = last_tooth;
                    wfe_err++;
                    if (wfe_err > 1) {
                        iterate = 2;
                    }
                }
                tth_ang += deg_per_tooth[tth - 1]; // add on time ahead of the tooth we stepped back to
            }
        } // end while


        if (iterate == 2) {
            DISABLE_INTERRUPTS;
            asm ( "nop\n" ); // something screwed up, place for breakpoint
            ENABLE_INTERRUPTS;
            // can't continue as didn't find a valid tooth
            return;
        }

        tmp_ang = tth_ang - spk_ang; // angle after trigger tooth we found
        //convert this small angle to time
        spk_time.time_32_bits = (tmp_ang * last_tooth_time.time_32_bits) / last_tooth_ang;

        wfe_err = 0;
        while ((wfe_err < 2) && (spk_time.time_32_bits < SPK_TIME_MIN)) {
            // too soon after tooth, need to step back
            tth--;
            if (tth < 1) {
                tth = last_tooth;
                wfe_err++;
            }
            tth_ang += deg_per_tooth[tth - 1]; // add on time ahead of the tooth we stepped back to
            // recalc
            tmp_ang = tth_ang - spk_ang;
            spk_time.time_32_bits = (tmp_ang * last_tooth_time.time_32_bits) / last_tooth_ang;
        }

        if (wfe_err > 1) {
            DISABLE_INTERRUPTS;
            asm ( "nop\n" ); // something screwed up, place for breakpoint
            ENABLE_INTERRUPTS;
            // can't continue as didn't find a valid tooth
            return;
        }

        spark_events_fill[(unsigned int)i].tooth = tth;
        spark_events_fill[(unsigned int)i].time = spk_time;
        spark_events_fill[(unsigned int)i].coil = i;

        // Code limits spark advance so spark point should always be ahead of or after
        // the trigger and not crossing it.
        // During next-cyl cranking we set this flag.
        // to force a spark at trigger.
        tmptime = (spk_ang * last_tooth_time.time_32_bits) / last_tooth_ang;

        if ((flash4.dwellmode & 3) == 3) {
            //if "charge on trigger", then dwell on same tooth as scheduling spark
            //might be ok for MSD in basic dizzy mode. Might give unpredictable short pulses
            // when combined with wheel mode.
            dwell_events_fill[(unsigned int)i].tooth = spark_events_fill[(unsigned int)i].tooth;
            dwell_events_fill[(unsigned int)i].time32 = 0;
        } else {
            // do normal dwell - assume that it must always start ahead of spark
            // so start from spark tooth

            wfe_err = 0;
            iterate = 0;
            while (!iterate) {
                if (tth_ang > dwl_ang) {
                    // found a suitable tooth
                    iterate = 1;
                } else {
                    //how far do we step back in deg
                    tth--;
                    if (tth < 1) {
                        tth = last_tooth;
                        wfe_err++;
                        if (wfe_err > 1) {
                            iterate = 2;
                        }
                    }
                    tth_ang += deg_per_tooth[tth - 1]; // add on time ahead of the tooth we stepped back to
                }
            } // end while

            if (iterate == 2) {
                DISABLE_INTERRUPTS;
                asm ( "nop\n" ); // something screwed up, place for breakpoint
                ENABLE_INTERRUPTS;
                // can't continue as didn't find a valid tooth
                return;
            }

            tmp_ang = tth_ang - dwl_ang; // angle after trigger tooth we found
            //convert this small angle to time
            dwl_time.time_32_bits = (tmp_ang * last_tooth_time.time_32_bits) / last_tooth_ang;

            wfe_err = 0;
            while ((wfe_err < 2) && (dwl_time.time_32_bits < SPK_TIME_MIN)) {
                // too soon after tooth, need to step back
                tth--;
                if (tth < 1) {
                    tth = last_tooth;
                    wfe_err++;
                }
                tth_ang += deg_per_tooth[tth - 1]; // add on time ahead of the tooth we stepped back to
                // recalc
                tmp_ang = tth_ang - dwl_ang;
                dwl_time.time_32_bits = (tmp_ang * last_tooth_time.time_32_bits) / last_tooth_ang;
            }

            if (wfe_err > 1) {
                DISABLE_INTERRUPTS;
                asm ( "nop\n" ); // something screwed up, place for breakpoint
                ENABLE_INTERRUPTS;
                // can't continue as didn't find a valid tooth
                return;
            }

            dwell_events_fill[(unsigned int)i].tooth = tth;
            dwell_events_fill[(unsigned int)i].time = dwl_time;
        }
        dwell_events_fill[(unsigned int)i].coil = i;

        // if dwell has stepped back then force dwell on tooth just before spark
        // or if dwell is on same tooth but fairly short then force it
        if ((dwell_events_fill[(unsigned int)i].tooth != spark_events_fill[(unsigned int)i].tooth)
                || ( (dwell_events_fill[(unsigned int)i].tooth == spark_events_fill[(unsigned int)i].tooth)
                    && (dwell_events_fill[(unsigned int)i].time32 < 170)
                    && (dwell_events_fill[(unsigned int)i].time32 >= 0) ) ) {
            spark_events_fill[(unsigned int)i].ftooth = spark_events_fill[(unsigned int)i].tooth;
        } else {
            spark_events_fill[(unsigned int)i].ftooth = 0;
        }
    }
}

void wheel_fill_fuel_event_array(fuel_event *fuel_events_fill, int fuel_ang, ign_time last_tooth_time,
                                 unsigned int last_tooth_ang, unsigned char siamese)
{
    char start, stop, iterate, tth, wfe_err;
    int tth_ang, tmp_ang;
    unsigned int fuel_time;
    unsigned char i, j, increment, pos=0;

    if(siamese == 4) {
        // Semi-sequential siamese: trigger on cylinder 1 (and 4)
        start = 0;
        stop = no_triggers;
        increment = 2;
    } else if (siamese < 4) {
        start = siamese;
        stop = siamese + 1;
        increment = 1;
        pos = 1 - (siamese / 2);
    } else {
        start = siamese - 10;
        stop = no_triggers;
        increment = no_triggers / no_squirts;
    }
    for (i = start, j = pos; i < stop; i+=increment, j++) {
        int tmp_inj_ang;

        wfe_err = 0;
        iterate = 0;
        tth_ang = trig_angs[i]; // trigger angle for this trigger to allow for oddfire
        tth = trigger_teeth[i];
        tmp_inj_ang = fuel_ang;

        if (tth_ang > tmp_inj_ang) {
            tmp_inj_ang += cycle_deg;
        }

        while (!iterate) {
            if (tth_ang > tmp_inj_ang) {  // must both be signed to get comparison to work
                // found a suitable tooth
                iterate = 1;
            } else {
                //how far do we step back in deg
                tth--;
                if (tth < 1) {
                    tth = last_tooth;
                    wfe_err++;
                    if (wfe_err > 2) {
                        iterate = 3;
                    }
                }
                tth_ang += deg_per_tooth[tth - 1]; // add on time ahead of the tooth we stepped back to
            }
        } // end while


        if (iterate == 3) {
            DISABLE_INTERRUPTS;
            asm ( "nop\n" ); // something screwed up, place for breakpoint
            ENABLE_INTERRUPTS;
            // can't continue as didn't find a valid tooth
            return;
        }

        tmp_ang = tth_ang - tmp_inj_ang; // angle after trigger tooth we found
        //convert this small angle to software timer count
        fuel_time = (unsigned int)(((tmp_ang * last_tooth_time.time_32_bits) / last_tooth_ang) / 192L);

        if (fuel_time < 1) {
            fuel_time = 1;
        }
        fuel_events_fill[j].tooth = tth;
        fuel_events_fill[j].time = fuel_time;
        fuel_events_fill[j].inj = j;
    }
}

void syncfirst(void)
{
    signed int tmp_tooth;
    unsigned char i, start_val;

    // convenient common place to put this code
    if (((flash4.spk_mode3 & 0xe0) == 0x60) // this is permanent wasted-COP mode
        && (!((flash4.spk_mode3 & 0x01) // but not the things needed for MAP phase detection
            && (flash4.no_cyl <= 2) && ((flash4.spk_config & 0x0c) == 0x0c)
            && ((flash4.spk_mode3 & 0xe0) == 0x60)
            && ((flash4.mapsample_opt & 0x04) == 0)))) {
        synch |= SYNC_WCOP2;
    }

/* check if we are somehow already at high rpms
   in that case skip these checks as not enough CPU time
    was previously preventing re-sync at higher rpms */
    if ((tooth_diff_this && (tooth_diff_this < 1800)) || (no_triggers == 1)) { // was 750
        start_val = 255;
    } else {
        start_val = 0;
    }

/* find next dwell event so we spark ASAP */
    fuel_cntr = start_val;
    tmp_tooth = tooth_no;
    while (!fuel_cntr) {
        tmp_tooth++;
        if (tmp_tooth > last_tooth) {
            tmp_tooth = 0;
        }
        if (tmp_tooth == tooth_no) {
            // been all the way around without finding anything - oops!
            fuel_cntr = 255;
        }
        for (i = 0; i < no_triggers; i++) {
            if (dwell_events[i].tooth == tmp_tooth) {
                fuel_cntr = i;
            } 
        }
    }
    if (fuel_cntr == 255) {
        fuel_cntr = 0;
    }

    next_spark.time = spark_events[fuel_cntr].time;
    next_spark.tooth = spark_events[fuel_cntr].tooth;
    next_spark.coil = spark_events[fuel_cntr].coil;
    next_spark.ftooth = spark_events[fuel_cntr].ftooth;
    next_spark.fs = spark_events[fuel_cntr].fs;
    next_dwell.time = dwell_events[fuel_cntr].time;
    next_dwell.tooth = dwell_events[fuel_cntr].tooth;
    next_dwell.coil = dwell_events[fuel_cntr].coil;

/* find next map event so we capture map ASAP */
    fuel_cntr = start_val;
    tmp_tooth = tooth_no;
    while (!fuel_cntr) {
        tmp_tooth++;
        if (tmp_tooth > last_tooth) {
            tmp_tooth = 0;
        }
        if (tmp_tooth == tooth_no) {
            // been all the way around without finding anything - oops!
            fuel_cntr = 255;
        }
        for (i = 0; i < no_triggers; i++) {
            if (map_start_event[i].tooth == tmp_tooth) {
                fuel_cntr = i;
            } 
        }
    }
    if (fuel_cntr == 255) {
        fuel_cntr = 0;
    }

    next_map_start_event.time = map_start_event[fuel_cntr].time;
    next_map_start_event.tooth = map_start_event[fuel_cntr].tooth;
    next_map_start_event.evnum = map_start_event[fuel_cntr].evnum;
    // don't use ftooth or fs in dwell array
        if ((flash8.seq_inj & 0x03) != 0) {     
                unsigned char inj_event;
                if ((flash8.seq_inj & 0x03) > 1) {      
                        inj_event = fuel_cntr>>1;
                } else {
                        inj_event = fuel_cntr / no_inj;
                }
            next_fuel1_event.time = fuel1_events[inj_event].time;
            next_fuel1_event.tooth = fuel1_events[inj_event].tooth;
            next_fuel1_event.inj = fuel1_events[inj_event].inj;
            next_fuel2_event.time = fuel2_events[inj_event].time;
            next_fuel2_event.tooth = fuel2_events[inj_event].tooth;
            next_fuel2_event.inj = fuel2_events[inj_event].inj;
                if (!(seq_inj_ctrl & SEQ_STD_INJ)) {
                    next_fuel3_event.time = fuel3_events[inj_event].time;
                    next_fuel3_event.tooth = fuel3_events[inj_event].tooth;
                    next_fuel3_event.inj = fuel3_events[inj_event].inj;
                    next_fuel4_event.time = fuel4_events[inj_event].time;
                    next_fuel4_event.tooth = fuel4_events[inj_event].tooth;
                    next_fuel4_event.inj = fuel4_events[inj_event].inj;
                }
        }

/* find next fuel event */
    fuel_cntr = start_val;
    tmp_tooth = tooth_no;
    while (!fuel_cntr) {
        tmp_tooth++;
        if (tmp_tooth > last_tooth) {
            tmp_tooth = 0;
        }
        if (tmp_tooth == tooth_no) {
            // been all the way around without finding anything - oops!
            fuel_cntr = 255;
        }
        for (i = 0; i < no_triggers; i++) {
            if (trigger_teeth[i] == tmp_tooth) {
                fuel_cntr = i;
            } 
        }
    }
    if (fuel_cntr == 255) {
        fuel_cntr = 0;
    }
    next_fuel = trigger_teeth[fuel_cntr];

    if ((next_spark.tooth != 0) &&
            (next_dwell.tooth != 0)) {
        synch &= ~SYNC_FIRST;  // must have non zero values before declaring sync not first
    }

    if (((spkmode == 4) || (spkmode == 7)) && ((flash4.EngStroke & 0x03) == 0x03)) {
        next_spk_trl.time = spark_events[2].time;
        next_spk_trl.tooth = spark_events[2].tooth;
        next_spk_trl.coil = spark_events[2].coil;
        next_dwl_trl.time = dwell_events[2].time;
        next_dwl_trl.tooth = dwell_events[2].tooth;
        next_dwl_trl.coil = dwell_events[2].coil;   
        if ((next_spk_trl.tooth != 0) && (next_dwl_trl.tooth != 0)) {
            synch &= ~SYNC_FIRST;  // must have non zero values before declaring sync not first
        }
    }
    outpc.status1 |= STATUS1_SYNCOK;
}

void recheck_syncfirst(void)
{
    /* Check for situation where SYNC_FIRST is off, but trigger teeth are not
        actually valid. This can occur if MS2 is powered on (or a reset) at high
        rpms and syncfirst runs before the event arrays are filled. More prevalent
        with certain tooth#1 angles.
        Does not happen during a normal start.
    */
    if (!(synch & SYNC_FIRST)) { // supposed to have picked up next trigger points
        if (next_spark.tooth == 0) { // but not actually pointing to valid tooth
            DISABLE_INTERRUPTS;
            next_spark.time = spark_events[0].time;
            next_spark.tooth = spark_events[0].tooth;
            next_spark.coil = spark_events[0].coil;
            next_spark.ftooth = spark_events[0].ftooth;
            next_spark.fs = spark_events[0].fs;
            ENABLE_INTERRUPTS;
        }
        if (next_dwell.tooth == 0) {
            DISABLE_INTERRUPTS;
            next_dwell.time = dwell_events[0].time;
            next_dwell.tooth = dwell_events[0].tooth;
            next_dwell.coil = dwell_events[0].coil;
            ENABLE_INTERRUPTS;
        }
        if (next_map_start_event.tooth == 0) {
            DISABLE_INTERRUPTS;
            next_map_start_event.time = map_start_event[fuel_cntr].time;
            next_map_start_event.tooth = map_start_event[fuel_cntr].tooth;
            next_map_start_event.evnum = map_start_event[fuel_cntr].evnum;
            ENABLE_INTERRUPTS;
        }
        if ((flash8.seq_inj & 0x03) != 0) {
            if (next_fuel1_event.tooth == 0) {
                DISABLE_INTERRUPTS;
                next_fuel1_event.time = fuel1_events[0].time;
                next_fuel1_event.tooth = fuel1_events[0].tooth;
                next_fuel1_event.inj = fuel1_events[0].inj;
                ENABLE_INTERRUPTS;
            }
            if (next_fuel2_event.tooth == 0) {
                DISABLE_INTERRUPTS;
                next_fuel2_event.time = fuel2_events[0].time;
                next_fuel2_event.tooth = fuel2_events[0].tooth;
                next_fuel2_event.inj = fuel2_events[0].inj;
                ENABLE_INTERRUPTS;
            }
            if (!(seq_inj_ctrl & SEQ_STD_INJ)) {
                if (next_fuel3_event.tooth == 0) {
                    DISABLE_INTERRUPTS;
                    next_fuel3_event.time = fuel3_events[0].time;
                    next_fuel3_event.tooth = fuel3_events[0].tooth;
                    next_fuel3_event.inj = fuel3_events[0].inj;
                    ENABLE_INTERRUPTS;
                }
                if (next_fuel4_event.tooth == 0) {
                    DISABLE_INTERRUPTS;
                    next_fuel4_event.time = fuel4_events[0].time;
                    next_fuel4_event.tooth = fuel4_events[0].tooth;
                    next_fuel4_event.inj = fuel4_events[0].inj;
                    ENABLE_INTERRUPTS;
                }
            }
        }
        if (next_fuel == 0) {
            DISABLE_INTERRUPTS;
            next_fuel = trigger_teeth[fuel_cntr];
            ENABLE_INTERRUPTS;
        }
        if (((spkmode == 4) || (spkmode == 7)) && ((flash4.EngStroke & 0x03) == 0x03)) {
            if (next_spk_trl.tooth == 0) {
                DISABLE_INTERRUPTS;
                next_spk_trl.time = spark_events[2].time;
                next_spk_trl.tooth = spark_events[2].tooth;
                next_spk_trl.coil = spark_events[2].coil;
                ENABLE_INTERRUPTS;
            }
            if (next_dwl_trl.tooth == 0) {
                DISABLE_INTERRUPTS;
                next_dwl_trl.time = dwell_events[2].time;
                next_dwl_trl.tooth = dwell_events[2].tooth;
                next_dwl_trl.coil = dwell_events[2].coil;
                ENABLE_INTERRUPTS;
            }
        }
    }
}

void SET_COIL(unsigned char *coil, unsigned char *bits) {
    if ((flash4.EngStroke & 0x03) == 0x03) {
        if (*coil == TRIGA) {
            *bits |= COILABIT;
        } else if (*coil == TRIGB) {
            *bits |= COILBBIT;
        } else if (*coil == TRIGC) {
            *bits |= COILCBIT;
        } else if (*coil == TRIGD) {
            *bits |= COILDBIT;
        }
    } else {
        if (*coil == TRIGA) {
            *bits |= COILABIT;
        } else if (*coil == TRIGB) {
            if (num_spk == 1) {
                *bits |= COILABIT;
            } else {
                *bits |= COILBBIT;
            }
        } else if (*coil == TRIGC) {
            if (num_spk == 1) {
                *bits |= COILABIT;
            } else if (num_spk == 2) {
                *bits |= COILABIT;
            } else {
                *bits |= COILCBIT;
            }
        } else if (*coil == TRIGD) {
            if (num_spk == 1) {
                *bits |= COILABIT;
            } else if (num_spk == 2) {
                *bits |= COILBBIT;
            } else if (num_spk == 3) {
                *bits |= COILABIT;
            } else {
                *bits |= COILDBIT;
            }
        } else if (*coil == TRIGE) {
            if (num_spk == 1) {
                *bits |= COILABIT;
            } else if (num_spk == 2) {
                *bits |= COILABIT;
            } else if (num_spk == 3) {
                *bits |= COILBBIT;
            } else if (num_spk == 4) {
                *bits |= COILABIT;
            } else {
                *bits |= COILEBIT;
            }
        } else if (*coil == TRIGF) {
            if (num_spk == 1) {
                *bits |= COILABIT;
            } else if (num_spk == 2) {
                *bits |= COILBBIT;
            } else if (num_spk == 3) {
                *bits |= COILCBIT;
            } else if (num_spk == 4) {
                *bits |= COILBBIT;
            } else {
                *bits |= COILFBIT;
            }
        } else if (*coil == TRIGG) {
            if (num_spk == 1) {
                *bits |= COILABIT;
            } else if (num_spk == 2) {
                *bits |= COILABIT;
            } else if (num_spk == 4) {
                *bits |= COILCBIT;
            } else {
                *bits |= COILGBIT;
            }
        } else if (*coil == TRIGH) {
            if (num_spk == 1) {
                *bits |= COILABIT;
            } else if (num_spk == 2) {
                *bits |= COILBBIT;
            } else if (num_spk == 4) {
                *bits |= COILDBIT;
            } else {
                *bits |= COILHBIT;
            }
        }
    }
}

void calc_advance()
{
    unsigned char uctmp;
    int base_timing, adv1 = 0, adv2 = 0, adv3 = 0, rl_rtd = 0, idlecor = 0;

    //DIST_ADV:
    // Table switching
    uctmp = 0; //uctmp is local tmp var
    // nitrous control will also use this var as pin behaviour will be different
    //note: doesn't block DT as not believed to have any effect
    if (flash5.feature5_0 & 0x10) { //  table switching
        if ((flash5.feature5_0 & 0x60) == 0) {
            if (flash5.ts_port & 0x80) {
                // Remote switch
                if (!(outpc.gpioport[2] & (0x01 << ((flash5.ts_port & 0x70) >> 4)))) {
                    uctmp = 1;
                }
            } else if ((flash5.ts_port & 0x0f) == 1) {
                // Local switch
                if (!(PORTE & 0x1)) { // PE0/FLEX. Pullup always enabled.
                    uctmp = 1;
                }
            } else {
                // Local switch
                if (!(PORTE & 0x2)) { // the bastard pin. Pullup always enabled.
                    uctmp = 1;
                }
            }
        } else if ((flash5.feature5_0 & 0x60) == 0x20) {
            if (outpc.rpm > flash5.tss_rpm) {
                uctmp = 1;
            }
        } else if ((flash5.feature5_0 & 0x60) == 0x40) {
            if (outpc.map > flash5.tss_kpa) {
                uctmp = 1;
            }
        } else if ((flash5.feature5_0 & 0x60) == 0x60) {
            if (outpc.tps > flash5.tss_tps) {
                uctmp = 1;
            }
        }
    }

    if (uctmp) {
        outpc.status1 |= status1_stblsw;
    } else {
        outpc.status1 &= ~status1_stblsw;
    }

    // Calculate ignition advance
    if (outpc.engine & ENGINE_CRANK) {
        if ( ((spkmode == 2) || (spkmode == 3) || (spkmode == 14) )&& (flash4.adv_offset <= 200) ) {  //2,3
            lsum_ign = flash4.adv_offset; // next-cyl fire at trigger on in dizzy modes
        } else {
            lsum_ign = flash4.crank_timing;
        }
        base_timing = lsum_ign;
    } else if (pg4_ptr->timing_flags & TIMING_FIXED) {
        base_timing = pg4_ptr->fixed_timing;
        lsum_ign = pg4_ptr->fixed_timing;
    } else {

        if (uctmp) { // table switching
            adv3 = intrp_2ditable(outpc.rpm, outpc.ignload, NO_SRPMS, NO_SMAPS,
                    &pg8_ptr->srpm_table3[0], &pg8_ptr->smap_table3[0], (int *)&pg8_ptr->adv_table3[0][0]);
            lsum_ign = adv3;
        } else {
            adv1 = intrp_2ditable(outpc.rpm, outpc.ignload, NO_SRPMS, NO_SMAPS,
                    &pg10_ptr->srpm_table[0][0], &pg10_ptr->smap_table[0][0], (int *)&pg10_ptr->adv_table[0][0][0]);
            lsum_ign = adv1;
        }
        base_timing = lsum_ign;

        if (flash8.idle_special_ops & IDLE_SPECIAL_OPS_IDLEADVANCE_LOAD 
                || flash8.idle_special_ops & IDLE_SPECIAL_OPS_IDLEADVANCE_RPM
                || flash8.idle_special_ops & IDLE_SPECIAL_OPS_IDLEADVANCE_ADAPTIVE) {
            char doit = 0;
            if ((flash8.idle_special_ops & IDLE_SPECIAL_OPS_IDLEADVANCE_CL_COND) 
                && (outpc.status2 & status2_pwmidle_closedloop)) {
                doit = 1;
            } else if (!(flash8.idle_special_ops & IDLE_SPECIAL_OPS_IDLEADVANCE_CL_COND) &&
            (outpc.tps < flash8.idleadvance_tps) &&
                    (outpc.rpm < flash8.idleadvance_rpm) &&
                    (outpc.fuelload > flash8.idleadvance_load) &&
                    (outpc.clt > flash8.idleadvance_clt)) {
                doit = 1;
            } else {
                flagbyte4 &= ~flagbyte4_idleadvreset;
            }

            if(doit && (idle_advance_timer >= flash8.idleadvance_delay) &&
                        (flagbyte4 & flagbyte4_idleadvreset)) {
                    /* deg x 10 */

                    long t = 0;

                    if (flash8.idle_special_ops & IDLE_SPECIAL_OPS_IDLEADVANCE_LOAD) {
                        t = intrp_1ditable(outpc.fuelload, 5, (int *)pg12_ptr->idleadvance_loads, 1, (int *)pg12_ptr->idleadvance_curve);
                    }

                    if (flash8.idle_special_ops & IDLE_SPECIAL_OPS_IDLEADVANCE_RPM) {
                        t = intrp_1ditable(outpc.rpm, 5, (int *)pg12_ptr->idleadvance_rpms, 1, (int *)pg12_ptr->idleadvance_curve);
                    }

                    if (flash8.idle_special_ops & IDLE_SPECIAL_OPS_IDLEADVANCE_ADAPTIVE) {
                        t = intrp_1ditable(outpc.rpm - targ_rpm, 5, (int *)pg12_ptr->idleadvance_rpms, 1, (int *)pg12_ptr->idleadvance_curve);
                    }

                    if (flash8.idle_special_ops & IDLE_SPECIAL_OPS_IDLEADVANCE_ADDER) {
                        idlecor = t;
                        lsum_ign += t;
                    } else {
                        base_timing = t;
                        lsum_ign = t;
                    }
                } else {
                    if (!(flagbyte4 &flagbyte4_idleadvreset)) {
                        DISABLE_INTERRUPTS;
                        idle_advance_timer = 0;
                        ENABLE_INTERRUPTS;
                        flagbyte4 |= flagbyte4_idleadvreset;
                    }
                }
        }

        lsum_ign += outpc.cold_adv_deg - outpc.knk_rtd; // degx 10
        // Subtract retard vs manifold air temp
        outpc.mat_retard = intrp_1dctable(outpc.airtemp, NO_MAT_TEMPS, (int *)flash5.MatTemps, 0, (unsigned char *)flash5.MatSpkRtd);    // %
        lsum_ign -= outpc.mat_retard;
        // correct for flex fuel;
        lsum_ign += outpc.flex_advance;    // degx10
        /* If the second table is enabled, use it */
        if (flash4.IgnAlgorithm & 0xF0) {
            adv2 = intrp_2ditable(outpc.rpm, outpc.ignload2, NO_SRPMS, NO_SMAPS,
                    &pg10_ptr->srpm_table[1][0], &pg10_ptr->smap_table[1][0], (int *)&pg10_ptr->adv_table[1][0][0]);
            /* Ign only additive */
            lsum_ign += adv2;
        }
        // rev limit
        if (flash4.RevLimOption & 1)  {
            if (outpc.rpm > RevLimRpm2) {
                rl_rtd = flash4.RevLimMaxRtd;                  // deg x 10
                outpc.status3 |= STATUS3_REVLIMSFT;
            } else if (outpc.rpm > RevLimRpm1)  {
                rl_rtd = (((long)flash4.RevLimMaxRtd*(outpc.rpm- RevLimRpm1))/
                        (RevLimRpm2 - RevLimRpm1));             // deg x 10
                outpc.status3 |= STATUS3_REVLIMSFT;
            } else {
                outpc.status3 &= ~STATUS3_REVLIMSFT;
            }
            lsum_ign -= rl_rtd;     // deg x 10
        } else if (flash4.RevLimOption & 2) {
            if ((outpc.rpm > RevLimRpm1) && (lsum_ign > flash4.RevLimRtdAng)) {      // made sure we are going to retard.
                rl_rtd = lsum_ign - flash4.RevLimRtdAng; // calculate in retard terms
                lsum_ign = flash4.RevLimRtdAng;
                outpc.status3 |= STATUS3_REVLIMSFT;
            } else {
                outpc.status3 &= ~STATUS3_REVLIMSFT;
            }

        }
    }
    outpc.adv1 = adv1;
    outpc.adv2 = adv2;
    outpc.adv3 = adv3;
    outpc.base_advance = base_timing;
    outpc.idle_cor_advance = idlecor;
    outpc.revlim_retard = rl_rtd;
}

void do_spkmode(void)
{
    unsigned int utmp1, utmp2;
    unsigned int rpm;
    signed int inttmp, latency_ang, last_tooth_ang, 
               last_tooth_ang_prev, spk_req_ang, dwl_req_ang;
    unsigned long max_dwl_time, longtmp;
    unsigned long dtpred_local, dtpred_last_local, dtpred_last_local2, dtpred_last_local3;
    ign_event *dwell_events_fill, *spark_events_fill;
    fuel_event *fuel1_events_fill=NULL, *fuel2_events_fill=NULL, *fuel3_events_fill=NULL, *fuel4_events_fill=NULL;
    ign_time last_tooth_time, spk_time, dwl_time;
    ign_time last_tooth_time_prev;
    unsigned char last_tooth_no, last_tooth_no_prev;
    long longtmp2;

    DISABLE_INTERRUPTS;
    last_tooth_time = tooth_diff_rpm;
    last_tooth_time_prev = tooth_diff_rpm_last;
    dtpred_local = dtpred;
    dtpred_last_local = dtpred_last;
    dtpred_last_local2 = dtpred_last2;
    dtpred_last_local3 = dtpred_last3;
    last_tooth_no = tooth_no_rpm;
    ENABLE_INTERRUPTS;

    // sometimes when reconfiguring spark modes, might get here with last_tooth == 0, which is meaningless
    if (last_tooth == 0) {
        goto END_WHEEL_DECODER;
    }

    // figure out angle between this tooth and previous one
    // array holds angle _ahead_ of the tooth, so step back a tooth
    last_tooth_no--;
    if ((char)last_tooth_no <=0) {
        last_tooth_no = last_tooth;
    }
    // make sure we don't land on a zero one
    while ((last_tooth_ang = deg_per_tooth[last_tooth_no-1]) == 0) {
        last_tooth_no--;
        if ((char)last_tooth_no <=0) {
            last_tooth_no = last_tooth;
        }
    }

    // see if we have new data to look at
    if (flagbyte22 & FLAGBYTE22_NEW_TOOTH) {
        unsigned long ultmp, ultmp2;

        DISABLE_INTERRUPTS;
        flagbyte22 &= ~FLAGBYTE22_NEW_TOOTH;
        ENABLE_INTERRUPTS;

        // Now do this calc
        // ticks per degree = last_tooth_time / last_tooth_ang
        // @ 50    rpm   5000    ticks per deg
        // @ 15000 rpm     16.66 ticks per deg
        // Would need to say *100 and use a ulong to retain precision
        // Use ultmp as ticks/deg * 1000 (degs is in 0.1deg)
        ultmp = (last_tooth_time.time_32_bits * 1000) / (unsigned long)last_tooth_ang;

        if (outpc.rpm == 1) {
            unsigned int newrpm;
            /* calc estimated rpm from the ticks/deg */
            newrpm = 25000000L / ultmp;

            /* check for possible invalid high rpm caused by noise pulse on very first pulse */
            if (newrpm > flash4.crank_rpm) {
                outpc.rpm = flash4.crank_rpm >> 1; // use half of set cranking rpm instead just this time
            } else {
                outpc.rpm = newrpm;
            }
        }

        // figure out how accurately we predicted ticks per deg  -12.7% to +12.7%   
        // - means current period is shorter, + means current period is longer
        // Can't easily compute as degree error like in MS2 because we are handling uneven
        // wheels and the degree error will depend on which tooth we are predicing over
        // %age should be more meaningful
        longtmp2 = (long)ultmp - (long)ticks_per_deg;
        //                  outpc.gpioadc[2] = (signed int)longtmp2; // feedback of actual error
        longtmp2 = (longtmp2 * 1000) / (long)ultmp;
        if (longtmp2 < -127) {
            longtmp2 = -127;
        } else if (longtmp2 > 127) {
            longtmp2 = 127;
        }
        outpc.timing_err = (char)longtmp2;

        if (flash4.timing_flags & USE_PREDICTION) {
            // figure out angle between previous tooth and previous-previous one
            // array holds angle _ahead_ of the tooth, so step back a tooth
            last_tooth_no_prev = last_tooth_no - 1;
            if ((char)last_tooth_no_prev <=0) {
                last_tooth_no_prev = last_tooth;
            }
            // make sure we don't land on a zero one
            while ((last_tooth_ang_prev = deg_per_tooth[last_tooth_no_prev-1]) == 0) {
                last_tooth_no_prev--;
                if (last_tooth_no_prev == 0) {
                    last_tooth_no_prev = last_tooth;
                }
            }

            ultmp2 = (last_tooth_time_prev.time_32_bits * 1000) / (unsigned long)last_tooth_ang_prev;
            // do first deriv prediction
            ultmp = (ultmp<<1) - ultmp2;
        }

        ticks_per_deg = ultmp;
    }

    if (synch & SYNC_SYNCED) {
        if (synch & SYNC_RPMCALC) {
            if ((flash4.ICIgnOption & 0x8) &&
                    ((spkmode == 2) ||
                     (spkmode == 14) ||
                     (spkmode == 31)) ) { // oddfire dizzy + twin trigger + fuel only
                unsigned long tdt,tdl;
                DISABLE_INTERRUPTS;
                tdt = tooth_diff_this;
                tdl = tooth_diff_last;
                ENABLE_INTERRUPTS;
                rpm = Rpm_Coeff / ((tdt + tdl)>>1);
            } else {
                if (dtpred_local < 2) { // avoid risk of divide by zero
                    rpm = 2;
                } else {
                    if (flash4.ICIgnOption & 0x8) {
                        /* always do it the VMAX way as other oddfire engines need it too */
                        rpm = Rpm_Coeff / ((dtpred_local + dtpred_last_local + dtpred_last_local2 + dtpred_last_local3) >> 2);
                    } else if ((flash4.no_cyl & 0x1f) == 1) { /* one cylinder averages over two revs */
                        rpm = Rpm_Coeff / ((dtpred_local + dtpred_last_local) >> 1);
                    } else {
                        rpm = Rpm_Coeff / dtpred_local;
                    }
                }
            }
            if ((flagbyte15 & FLAGBYTE15_FIRSTRPM) == 0) {
                flagbyte15 |= FLAGBYTE15_FIRSTRPM;
                outpc.rpm = 1;
            } else if (outpc.rpm < 3) {
                /* check for likely invalid high rpm caused by noise pulse on very first pulse */
                if (rpm > flash4.crank_rpm) {
                    outpc.rpm = flash4.crank_rpm >> 1; // use half of set cranking rpm instead just this time
                } else {
                    outpc.rpm = rpm;
                }
            } else if (outpc.engine & ENGINE_CRANK) {
                    outpc.rpm = rpm;
            } else {
                outpc.rpm += (int)((flash4.rpmLF * ((long)rpm - outpc.rpm)) / 100);
            }
            calc_rpmdot();
            synch &= ~SYNC_RPMCALC;
            if (flagbyte0 & (FLAGBYTE0_MAPLOG | FLAGBYTE0_MAFLOG)) {
                /* Calculate how infrequently to sample at low revs. This aims
                   to give a full 720 deg of data when sampled every 0.128ms
                   and allowing for tooth data. */
                maplog_max = 1 + (unsigned char)(2344 / outpc.rpm);
            } else if ((flagbyte0 & FLAGBYTE0_ENGLOG) && (page >= 0xf6)) { // 3 byte
                // numbers chosen as a balance between precision and data points
                maplog_max = 1 + (unsigned char)(2700 / outpc.rpm);
            } else if (flagbyte0 & FLAGBYTE0_ENGLOG) { // 2 byte
                // numbers chosen as a balance between precision and data points
                maplog_max = 1 + (unsigned char)(2344 / outpc.rpm);
            }
        }
    } else {
        if (!(synch & SYNC_SEMI2)) {
            outpc.rpm = 0;
        }
    }

    if ((flash8.seq_inj & 0x03) == 3) {
        if (seq_inj_ctrl & SEQ_HYBRID) {
            if (outpc.rpm < hybrid_rpm - hybrid_hyst) {
                seq_inj_ctrl &= ~SEQ_HYBRID;    // Hybrid mode deactivated
            }
        } else {
            if (outpc.rpm > hybrid_rpm) {
                seq_inj_ctrl |= SEQ_HYBRID;             // Hybrid mode activated
            }
        }
    }

    /* if we're synced and/or we're supposed to calc */
    if ((last_tooth_time.time_32_bits != 0) && dtpred_local) {
        if (dwell_events == dwell_events_a) {
            spark_events_fill = spark_events_b;
            dwell_events_fill = dwell_events_b;
        } else {
            spark_events_fill = spark_events_a;
            dwell_events_fill = dwell_events_a;
        }

        spk_time.time_32_bits = 0;
        dwl_time.time_32_bits = 0;

        if ((flash8.seq_inj & 0x03) != 0) {     
            if (fuel1_events == fuel1_events_a) {
                fuel1_events_fill = fuel1_events_b;
            } else {
                fuel1_events_fill = fuel1_events_a;
            }
            if (fuel2_events == fuel2_events_a) {
                fuel2_events_fill = fuel2_events_b;
            } else {
                fuel2_events_fill = fuel2_events_a;
            }
            if (fuel3_events == fuel3_events_a) {
                fuel3_events_fill = fuel3_events_b;
            } else {
                fuel3_events_fill = fuel3_events_a;
            }
            if (fuel4_events == fuel4_events_a) {
                fuel4_events_fill = fuel4_events_b;
            } else {
                fuel4_events_fill = fuel4_events_a;
            }

            //fuel_time.time_32_bits = 0;
        }

        /* figure out based on period time and num_spk how much time we actually
         * have for dwell.
         */

        if (((flash4.EngStroke & 0x03) == 0x03) || (flagbyte11 & (FLAGBYTE11_DLI4 | FLAGBYTE11_DLI4))) {
            /* rotary or DLI force 1 */
            max_dwl_time = dtpred_local;
        } else if (flash4.ICIgnOption & 0x8) {
            if (num_spk == 1) {
                // in odd fire set max dwell for shorter period
                if (dtpred_last_local < dtpred_local) {
                    max_dwl_time = dtpred_last_local;
                } else {
                    max_dwl_time = dtpred_local;
                }
            } else {
                // use average time.. might work or not
                max_dwl_time = ((dtpred_local + dtpred_last_local) >> 1) * num_spk;
            }
        } else {
            max_dwl_time = dtpred_local * num_spk;
        }

        // allow for known latency in bit-bash outputs
        latency_ang = (unsigned int)(((OUTPUT_LATENCY + flash4.hw_latency) * 1000UL) / ticks_per_deg);
        inttmp = latency_ang + lsum_ign;

        if (spkmode < 2) { // EDIS
            lsum_ign -= pg4_ptr->adv_offset;
            coil_dur = 2304 - ((983 * lsum_ign) /  256); //1536 - (adv*25.6) us //takes 9, still crappy asm
            utmp1 = coil_dur / 100;
        } else {
            if ((flash4.dwellmode & 3) == 0) {
                //normal dwell
                if ((outpc.engine & ENGINE_CRANK) || (outpc.rpm < 5)) {
                    utmp2 = flash4.crank_dwell;
                } else {
                    utmp2 = flash4.max_coil_dur;
                }
                utmp1 = utmp2 * coil_dur_table(outpc.batt);
                // utmp1 /= 50; // this generates silly ASM
                __asm__ __volatile__ ( "ldx #50\n"
                        "idiv\n"
                        : "=x" (utmp1)
                        : "d" (utmp1) // already in D from previous calc
                        );

                // prevent under or overflow
                if (utmp2 == 0) {
                    utmp1 = utmp2;
                } else if (utmp2 > 255) {
                    utmp1 = 255;
                }

                /* Rotary trailing dwell */
                if (((flash4.EngStroke & 0x03) == 0x03)) {
                    utmp2 =
                        flash10.dwelltime_trl * coil_dur_table(outpc.batt);
                        __asm__ __volatile__("ldx #50\n" "idiv\n":"=x"(utmp2)
                            :"d"(utmp2)    // already in D from previous calc
                            );

                    /* prevent under or overflow */
                    if (utmp2 == 0) {
                        utmp2 = flash10.dwelltime_trl;
                    } else if (utmp2 > 255) {
                        utmp2 = 255;
                    }
                    outpc.dwell_trl = utmp2;
                }

            } else if ((flash4.dwellmode & 3) == 1) {
                //dwell duty
                if (dtpred_local > 1500000) {
                    utmp1 = 10000; // top limit, prevents overflow
                } else {
                    // had to work to avoid overflows in here
                    longtmp = (num_spk * dtpred_local) / 100; // convert to 0.0667ms units
                    longtmp = longtmp * flash4.dwellduty; // /256 and convert ticks to 0.1ms
                    utmp1 = longtmp / 256;
                }
            } else if ((flash4.dwellmode & 3) == 2) {
                // time after spark (Saab trionic)
                utmp1 = flash4.dwelltime;
            } else {
                utmp1 = 0; // unknown if dwell at trigger
            }
        }

        longtmp = (unsigned long)utmp1 * 100;

        if ((flash4.dwellmode & 3) == 0) {
            /* should not be possible to exceed time period in other modes as it has already been taken into account */
            unsigned long disch = flash4.max_spk_dur * 100UL;
            if ((longtmp + disch) > max_dwl_time) {
                /* if (charge + discharge) exceeds available time then scale back in proportion */
                longtmp = (longtmp * max_dwl_time) / (longtmp + disch);
            }
        }

        if ((flash4.dwellmode & 3) != 2) {
            DISABLE_INTERRUPTS;
            dwell_long = longtmp;
            ENABLE_INTERRUPTS;
        }
        outpc.coil_dur = longtmp / 100; // shows dwell reduction due to spark duration

        /* END OF DWELL STUFF. NOW DO TIME CALCS */

        if ( (spkmode == 2) || (spkmode == 3) || (spkmode == 14) ){ // dizzy mode or twin trig
            // check for out of range advance
            if (flash4.adv_offset > 200) { // this cyl
                if (inttmp > (flash4.adv_offset - 10)) {
                    inttmp = flash4.adv_offset - 10; // set to 1 deg less than trigger angle
                }
            } else { // next cyl
                if (inttmp < (flash4.adv_offset + 10)) {
                    inttmp = flash4.adv_offset + 10; // set to 1 deg more than trigger angle
                }
            }
        }

        spk_req_ang = inttmp; // deg*10

        // only need spark time to get to dwell time
        spk_time.time_32_bits = (((unsigned long)inttmp *  ticks_per_deg) / 1000UL);


        if ((flash4.dwellmode & 3) == 0) { /* normal dwell */
            unsigned int md;
            // have now calc target dwell.

            // overdwell protection - now always on
            /* use largest of primary or trailing dwell */
            if (outpc.coil_dur > outpc.dwell_trl) {
                md = (unsigned int) (longtmp / 106); /* 200% convert timer ticks to 0.128ms units*/
            } else {
                md = (unsigned int) ((outpc.dwell_trl * 100UL) / 106);
            }
            if (md > 255) {
                md = 255;
            }
            maxdwl = md;

            dwl_time.time_32_bits = spk_time.time_32_bits + longtmp;
        } else if ((flash4.dwellmode & 3) == 2) {
            maxdwl = 0; // no overdwell protection desired with time-after-spark
            dwl_time.time_32_bits = spk_time.time_32_bits - longtmp;
        } else { // fixed duty or charge-at-trigger
            maxdwl = 0; // no overdwell protection
            dwl_time.time_32_bits = spk_time.time_32_bits + longtmp;
        }

        // now convert dwell time to an angle using last tooth time
        dwl_req_ang = (dwl_time.time_32_bits * 1000) / ticks_per_deg;
        wheel_fill_event_array(spark_events_fill, dwell_events_fill, spk_req_ang,
                dwl_req_ang, last_tooth_time, last_tooth_ang, 0);


        if ((spkmode == 2) || (spkmode == 3)) { // 2,3 basic trigger i.e. distributor
            unsigned int delay_tmp;
            unsigned int ix;
            for (ix = 0 ; ix < no_triggers ; ix++) {
                if (pg4_ptr->adv_offset < 200) { // next cyl
                    if (flash4.ICIgnOption & 0x08) { // oddfire next-cyl
                        unsigned int iy;
                        iy = ix;
                        iy = ix + 1;
                        if (iy >= no_triggers) {
                            iy = 0;
                        }
                        if (spk_req_ang < pg4_ptr->adv_offset) {
                            delay_tmp = 0; // can't go later than trigger
                        } else {
                            delay_tmp = deg_per_tooth[iy] + pg4_ptr->adv_offset - spk_req_ang;
                            // for oddfire the calc is divided by two tooth periods so that when use do the calc we can
                            // still use the last period but the 65536 scaling calc does not overflow
                            // e.g. if last was 90 deg, but we want to delay 140 deg forwards -> overflow
                            // now  (140/(90+150) * 65536) = 38229 
                            dizzy_scaler[ix] = (unsigned int)(((unsigned long)delay_tmp << 16) / (deg_per_tooth[0] + deg_per_tooth[1]));
                        }
                    } else { // even fire next-cyl
                        if (spk_req_ang < pg4_ptr->adv_offset) {
                            delay_tmp = 0; // can't go later than trigger
                        } else {
                            delay_tmp = deg_per_tooth[ix] + pg4_ptr->adv_offset - spk_req_ang;
                            dizzy_scaler[ix] = (unsigned int)(((unsigned long)delay_tmp << 16) / deg_per_tooth[ix]);
                        }
                    }
                }  else { // this cyl
                    if (spk_req_ang > (pg4_ptr->adv_offset - 20)) {
                        delay_tmp = 20; // minimum 2deg delay
                    } else {
                        delay_tmp = pg4_ptr->adv_offset - spk_req_ang;
                    }
                    if (flash4.ICIgnOption & 0x08) { // oddfire this-cyl
                        dizzy_scaler[ix] = (unsigned int)(((unsigned long)delay_tmp << 16) / (deg_per_tooth[0] + deg_per_tooth[1]));
                    } else { // evenfire this-cyl
                        dizzy_scaler[ix] = (unsigned int)(((unsigned long)delay_tmp << 16) / deg_per_tooth[ix]);
                    }
                    if (spkmode == 3) {
                        // for trigger return set spark timer to fire very late, should only happen if trigger return missed
                        // and possibly for one spark during crank/run transition
                        trigret_scaler = (unsigned int)(((unsigned long)pg4_ptr->adv_offset << 16) / deg_per_tooth[ix]);
                    }
                } 
            }

        }  else if (spkmode == 14) { // twin trigger
            unsigned int delay_tmp;
            unsigned int ix;
            for (ix = 0 ; ix < no_triggers ; ix++) {
                if (pg4_ptr->adv_offset < 200) { // next cyl
                    if (spk_req_ang < pg4_ptr->adv_offset) {
                        delay_tmp = 0; // can't go later than trigger
                    } else {
                        delay_tmp = (deg_per_tooth[0] + deg_per_tooth[1]) + pg4_ptr->adv_offset - spk_req_ang;
                        // for oddfire the calc is divided by two tooth periods so that when use do the calc we can
                        // still use the last period but the 65536 scaling calc does not overflow
                        // e.g. if last was 90 deg, but we want to delay 140 deg forwards -> overflow
                        // now  (140/(90+150) * 65536) = 38229 
                        dizzy_scaler[ix] = (unsigned int)(((unsigned long)delay_tmp << 16) / (deg_per_tooth[0] + deg_per_tooth[1]));
                    }
                } else { // this cyl
                    if (spk_req_ang > (pg4_ptr->adv_offset - 20)) {
                        delay_tmp = 20; // minimum 2deg delay
                    } else {
                        delay_tmp = pg4_ptr->adv_offset - spk_req_ang;
                    }
                    dizzy_scaler[ix] = (unsigned int)(((unsigned long)delay_tmp << 16) / (deg_per_tooth[0] + deg_per_tooth[1]));
                }
            }
        }

        wheel_fill_map_event_array(map_start_event, flash4.mapsample_angle, last_tooth_time,
                last_tooth_ang); 

        if ((flash8.seq_inj & 0x03) != 0) {     
            long fuel_req_ang;
            /* Note, gcc optimises this code into fewer actual function calls, so not as bad as it looks. */

            fuel_req_ang = calc_fuel_req_ang (lsum_fuel1, tmp_pw1, pw_open1);
            if ((flash8.seq_inj & 0x03) == 1) {     
                wheel_fill_fuel_event_array(fuel1_events_fill, fuel_req_ang, last_tooth_time, last_tooth_ang, 10);
            } else if ((flash8.seq_inj & 0x03) == 2) {      
                wheel_fill_fuel_event_array(fuel1_events_fill, fuel_req_ang, last_tooth_time, last_tooth_ang, 4);
            } else if ((flash8.seq_inj & 0x03) == 3) {      
                wheel_fill_fuel_event_array(fuel1_events_fill, fuel_req_ang, last_tooth_time, last_tooth_ang, 2);
            }

            if ((flash8.seq_inj & 0x03) == 1) {     
                if (no_inj > 1) {
                    fuel_req_ang = calc_fuel_req_ang (lsum_fuel1, tmp_pw2, pw_open2);
                    if (spkmode == 54) {
                        wheel_fill_fuel_event_array(fuel2_events_fill, fuel_req_ang, last_tooth_time, last_tooth_ang, 13);
                    } else {
                        wheel_fill_fuel_event_array(fuel2_events_fill, fuel_req_ang, last_tooth_time, last_tooth_ang, 11);
                    }
                } else if ((no_inj == 1) && (flash10.staged & 0x07)) {
                    fuel_req_ang = calc_fuel_req_ang (lsum_fuel1, tmp_pw3, pw_open2);
                    wheel_fill_fuel_event_array(fuel2_events_fill, fuel_req_ang, last_tooth_time, last_tooth_ang, 10);
                }
            } else if ((flash8.seq_inj & 0x03) == 2) {      
                fuel_req_ang = calc_fuel_req_ang (lsum_fuel1, tmp_pw2, pw_open2);
                wheel_fill_fuel_event_array(fuel2_events_fill, fuel_req_ang, last_tooth_time, last_tooth_ang, 4);
            } else if ((flash8.seq_inj & 0x03) == 3) {      
                fuel_req_ang = calc_fuel_req_ang (lsum_fuel2, tmp_pw2, pw_open2);
                wheel_fill_fuel_event_array(fuel2_events_fill, fuel_req_ang, last_tooth_time, last_tooth_ang, 3);
            }

            if ((flash8.seq_inj & 0x03) == 3) {     
                fuel_req_ang = calc_fuel_req_ang (lsum_fuel1, tmp_pw1, pw_open2);
                wheel_fill_fuel_event_array(fuel2_events_fill, fuel_req_ang, last_tooth_time, last_tooth_ang, 0);
                fuel_req_ang = calc_fuel_req_ang (lsum_fuel2, tmp_pw2, pw_open1);
                wheel_fill_fuel_event_array(fuel1_events_fill, fuel_req_ang, last_tooth_time, last_tooth_ang, 1);
            }

            if (!(seq_inj_ctrl & SEQ_STD_INJ)) {
                if ((flash8.seq_inj & 0x03) == 1) {     
                    if (no_inj > 2) {
                        fuel_req_ang = calc_fuel_req_ang (lsum_fuel1, tmp_pw3, pw_open3);
                        wheel_fill_fuel_event_array(fuel3_events_fill, fuel_req_ang, last_tooth_time, last_tooth_ang, 12);
                        if (no_inj == 4) {
                            fuel_req_ang = calc_fuel_req_ang (lsum_fuel1, tmp_pw4, pw_open4);
                            wheel_fill_fuel_event_array(fuel4_events_fill, fuel_req_ang, last_tooth_time, last_tooth_ang, 13);
                        }
                    } else if ((no_inj == 2) && (flash10.staged & 0x07)) {
                        fuel_req_ang = calc_fuel_req_ang (lsum_fuel1, tmp_pw3, pw_open3);
                        wheel_fill_fuel_event_array(fuel3_events_fill, fuel_req_ang, last_tooth_time, last_tooth_ang, 10);
                        fuel_req_ang = calc_fuel_req_ang (lsum_fuel1, tmp_pw4, pw_open4);
                        wheel_fill_fuel_event_array(fuel4_events_fill, fuel_req_ang, last_tooth_time, last_tooth_ang, 11);
                    }
                } else if ((flash8.seq_inj & 0x03) == 3) {      
                    //if (tmp_pw3 > 0) {
                    fuel_req_ang = calc_fuel_req_ang (lsum_fuel1, tmp_pw3, pw_open4);
                    wheel_fill_fuel_event_array(fuel4_events_fill, fuel_req_ang, last_tooth_time, last_tooth_ang, 0);
                    fuel_req_ang = calc_fuel_req_ang (lsum_fuel1, tmp_pw3, pw_open3);
                    wheel_fill_fuel_event_array(fuel3_events_fill, fuel_req_ang, last_tooth_time, last_tooth_ang, 2);
                    //}
                    //if (tmp_pw4 > 0) {
                    fuel_req_ang = calc_fuel_req_ang (lsum_fuel2, tmp_pw4, pw_open3);
                    wheel_fill_fuel_event_array(fuel3_events_fill, fuel_req_ang, last_tooth_time, last_tooth_ang, 1);
                    fuel_req_ang = calc_fuel_req_ang (lsum_fuel2, tmp_pw4, pw_open4);
                    wheel_fill_fuel_event_array(fuel4_events_fill, fuel_req_ang, last_tooth_time, last_tooth_ang, 3);
                    //}
                }
            }
        }

        /* check for rare case of zero next fuel tooth */
        if (next_fuel1_event.tooth == 0) {
            next_fuel1_event.time = fuel1_events[0].time;
            next_fuel1_event.tooth = fuel1_events[0].tooth;
            next_fuel1_event.inj = fuel1_events[0].inj;
        }
        if ((next_fuel2_event.tooth == 0) && (no_inj > 1)) {
            next_fuel2_event.time = fuel2_events[0].time;
            next_fuel2_event.tooth = fuel2_events[0].tooth;
            next_fuel2_event.inj = fuel2_events[0].inj;
        }
        if ((next_fuel3_event.tooth == 0) && (no_inj > 2)) {
            next_fuel3_event.time = fuel3_events[0].time;
            next_fuel3_event.tooth = fuel3_events[0].tooth;
            next_fuel3_event.inj = fuel3_events[0].inj;
        }
        if ((next_fuel4_event.tooth == 0) && (no_inj > 3)) {
            next_fuel4_event.time = fuel4_events[0].time;
            next_fuel4_event.tooth = fuel4_events[0].tooth;
            next_fuel4_event.inj = fuel4_events[0].inj;
        }

        if ((flash4.EngStroke & 0x03) == 0x03) {
            long spk_time_tmp, dwl_time_tmp;
            // rotary
            inttmp = latency_ang + lsum_rot;
            spk_req_ang = inttmp; // deg*10

            // only need spark time to get to dwell time
            spk_time_tmp = (inttmp * (long)ticks_per_deg) / 1000L;

            dwl_time_tmp = outpc.dwell_trl * 100L;
            if (dwl_time_tmp > (long)max_dwl_time) {
                dwl_time_tmp = max_dwl_time;
            }
            dwl_time_tmp += spk_time_tmp;

            // now convert dwell time to an angle using last tooth time
            dwl_req_ang = (dwl_time_tmp * 1000L) / (long)ticks_per_deg;

            wheel_fill_event_array(spark_events_fill, dwell_events_fill, spk_req_ang,
                    dwl_req_ang, last_tooth_time, last_tooth_ang, 1);
        }

        DISABLE_INTERRUPTS;
        dwell_events = dwell_events_fill;
        spark_events = spark_events_fill;
        ENABLE_INTERRUPTS;
        if ((flash8.seq_inj & 0x03) != 0) {     
            DISABLE_INTERRUPTS;
            fuel1_events = fuel1_events_fill;
            fuel2_events = fuel2_events_fill;
            fuel3_events = fuel3_events_fill;
            fuel4_events = fuel4_events_fill;
            ENABLE_INTERRUPTS;
        }
    }
END_WHEEL_DECODER:;
}
