/* $Id: ms2_extra_main_vectors.h,v 1.2 2013/11/21 13:58:25 jsmcortina Exp $
 * Copyright 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013
 * James Murray and Kenneth Culver
 *
 * This file is a part of MS2/Extra.
 *
 * You should have received a copy of the code LICENSE along with this source,
 * ask on the www.msextra.com forum if you did not.
 *
 */

/*************************************************************************
 **************************************************************************
 **   M E G A S Q U I R T  II - 2 0 0 4 - V1.000
 **
 **   (C) 2003 - B. A. Bowling And A. C. Grippo
 **
 **   This header must appear on all derivatives of this code.
 **
 ***************************************************************************
 **************************************************************************/

/*************************************************************************
 **************************************************************************
 **   GCC Port
 **
 **   (C) 2004,2005 - Philip L Johnson
 **
 **   This header must appear on all derivatives of this code.
 **
 ***************************************************************************
 **************************************************************************/

/*************************************************************************
 **************************************************************************
 **   MS2/Extra
 **
 **   (C) 2006,2007,2008 - Ken Culver, James Murray (in either order)
 **
 **   This header must appear on all derivatives of this code.
 **
 ***************************************************************************
 **************************************************************************/

const tIsrFunc _vect[] VECT_ATTR = {      /* Interrupt table */
    UnimplementedISR,                 /* vector 63 */
    UnimplementedISR,                 /* vector 62 */
    UnimplementedISR,                 /* vector 61 */
    UnimplementedISR,                 /* vector 60 */
    UnimplementedISR,                 /* vector 59 */
    UnimplementedISR,                 /* vector 58 */
    UnimplementedISR,                 /* vector 57 */
    UnimplementedISR,                 /* vector 56 */
    UnimplementedISR,                 /* vector 55 */
    UnimplementedISR,                 /* vector 54 */
    UnimplementedISR,                 /* vector 53 */
    UnimplementedISR,                 /* vector 52 */
    UnimplementedISR,                 /* vector 51 */
    UnimplementedISR,                 /* vector 50 */
    UnimplementedISR,                 /* vector 49 */
    UnimplementedISR,                 /* vector 48 */
    UnimplementedISR,                 /* vector 47 */
    UnimplementedISR,                 /* vector 46 */
    UnimplementedISR,                 /* vector 45 */
    UnimplementedISR,                 /* vector 44 */
    UnimplementedISR,                 /* vector 43 */
    UnimplementedISR,                 /* vector 42 */
    UnimplementedISR,                 /* vector 41 */
    UnimplementedISR,                 /* vector 40 */
    CanTxIsr,                         /* vector 39 */
    CanRxIsr,                         /* vector 38 */
    CanRxIsr,                         /* vector 37 */
    UnimplementedISR,                 /* vector 36 */
    UnimplementedISR,                 /* vector 35 */
    UnimplementedISR,                 /* vector 34 */
    UnimplementedISR,                 /* vector 33 */
    UnimplementedISR,                 /* vector 32 */
    UnimplementedISR,                 /* vector 31 */
    UnimplementedISR,                 /* vector 30 */
    UnimplementedISR,                 /* vector 29 */
    UnimplementedISR,                 /* vector 28 */
    UnimplementedISR,                 /* vector 27 */
    UnimplementedISR,                 /* vector 26 */
    UnimplementedISR,                 /* vector 25 */
    UnimplementedISR,                 /* vector 24 */
    UnimplementedISR,                 /* vector 23 */
    UnimplementedISR,                 /* vector 22 */
    UnimplementedISR,                 /* vector 21 */
    ISR_SCI_Comm,                     /* vector 20 */
    UnimplementedISR,                 /* vector 19 */
    UnimplementedISR,                 /* vector 18 */
    UnimplementedISR,                 /* vector 17 */
    ISR_TimerOverflow,                /* vector 16 */
#ifndef MICROSQUIRT
    ISR_Ign_TimerOut,                 /* vector 15 timer 7*/
#else
    ISR_Rot_SpkTimerOut,              /* vector 15 timer 7*/  //*** JB INJ4 on uS module
#endif
#ifndef MICROSQUIRT
    ISR_Dwl_TimerOut,                 /* vector 14 timer 6*/
#else
    ISR_Rot_TimerOut,                 /* vector 14 timer 6*/  //*** JB INJ3 on uS module
#endif
#ifndef MICROSQUIRT
    ISR_TC5,                          /* vector 13 timer 5*/
#else
    ISR_Ign_TimerOut,                 /* vector 13 timer 5*/
#endif
#ifndef MICROSQUIRT
    ISR_Rot_SpkTimerOut,              /* vector 12 timer 4*/  //*** JB INJ4 on MS2
#else
    ISR_Dwl_TimerOut,                 /* vector 12 timer 4*/
#endif
    ISR_Inj2_TimerOut,                /* vector 11 timer 3*/
#ifndef MICROSQUIRT
    ISR_Rot_TimerOut,                 /* vector 10 timer 2*/  //*** JB INJ3 on MS2
#else
    ISR_TC5,                          /* vector 10 timer 2*/
#endif
    ISR_Inj1_TimerOut,                /* vector 09 timer 1*/
    ISR_Ign_TimerIn,                  /* vector 08 timer 0*/
    ISR_Timer_Clock,                  /* vector 07 */
    UnimplementedISR,                 /* vector 06 */
    UnimplementedISR,                 /* vector 05 */
    UnimplementedISR,                 /* vector 04 */
    UnimplementedISR,                 /* vector 03 */
    UnimplementedISR,                 /* vector 02 */
    UnimplementedISR,                 /* vector 01 */
    _start                            /* Reset vector */
};

