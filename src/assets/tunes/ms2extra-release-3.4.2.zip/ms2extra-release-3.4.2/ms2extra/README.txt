Quick guide instructions to installing MS2/Extra 3.4.x

1. If you are presently using a different code version on your MS2 you should
save you settings.
e.g. File->Save Tune As in TunerStudio

2. Ensure TunerStudio is closed and nothing is using your serial port.

3. Run the supplied ms2loader_win32.exe (e.g. double click on it) and follow the instructions.
NOTE!! Do not use any older MS2 type loaders - they WILL NOT WORK with MS2/Extra
ms2loader_win32.exe for Windows.
ms2loader_linux32bit for Linux.
ms2loader_macos for OSX on Intel based Mac.

Let me repeat that - YOU **MUST** USE the supplied ms2loader that matches
your operating system.
Linux and Mac loaders need to be run from the command prompt, starting in
the same directory as the firmware files. Do not try to double-click on them
from a graphical user interface as it likely won't work.

4. Using TunerStudio 2.6.x or later is REQUIRED.

5. Open TunerStudio.
    Usually, TunerStudio will be able to detect your firmware and
    automatically install the matching "ini" file.

6. In some cases you may need to do this manually:
   Go to Project Properties, tick Custom and click ... then browse to this
   directory (where you extracted the firmware) and find the "ini" file
    ("ECU definition") that matches your product.
  megasquirt2.ini  for Megasquirt-2
  microsquirt.ini  for cased Microsquirt units
  microsquirt-module.ini for Megasquirt ECUs based on the Microsquirt-module
  mspnp2.ini for MS PNP2 plug-n-play from DIYautotune.
Note: If you don't see the "ini" file extension then fix you "Folder Options"
    in Windows by unticking "Hide known file extension"

7. Note!! When first creating a tune, you MUST be connected to the Megasquirt 'online' or open
an existing MSQ file. If you start tuning offline with blank settings you will create huge
problems for yourself.

Come to  www.msextra.com  for support and documentation.

Please consider making a donation to the developers.
http://www.msextra.com/doc/donations.html
