/* $Id: ms2_extra_main_decls.h,v 1.6 2014/03/10 20:27:00 jsmcortina Exp $
 * Copyright 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013
 * James Murray and Kenneth Culver
 *
 * This file is a part of MS2/Extra.
 *
 * You should have received a copy of the code LICENSE along with this source,
 * ask on the www.msextra.com forum if you did not.
 *
 */

/*************************************************************************
 **************************************************************************
 **   M E G A S Q U I R T  II - 2 0 0 4 - V1.000
 **
 **   (C) 2003 - B. A. Bowling And A. C. Grippo
 **
 **   This header must appear on all derivatives of this code.
 **
 ***************************************************************************
 **************************************************************************/

/*************************************************************************
 **************************************************************************
 **   GCC Port
 **
 **   (C) 2004,2005 - Philip L Johnson
 **
 **   This header must appear on all derivatives of this code.
 **
 ***************************************************************************
 **************************************************************************/

/*************************************************************************
 **************************************************************************
 **   MS2/Extra
 **
 **   (C) 2006,2007,2008 - Ken Culver, James Murray (in either order)
 **
 **   This header must appear on all derivatives of this code.
 **
 ***************************************************************************
 **************************************************************************/

#ifndef _MS2_MAIN_DECLS
#define _MS2_MAIN_DEClS
// this gives warnings in gcc which is annoying, but using it does make some things easier
// now used by CAN and SCI routines that reference tables
// has a slightly different usage to MS2 2.8+
// It is important to note that although the tables are defined here, there are hardcoded refs to
// the tables within the code. Specifically in ms2_extra_can_isr.c
/*    unsigned int *addrRam, unsigned int *addrFlash, unsigned int  n_bytes */
const tableDescriptor tables[NO_TBLES] =  { 
    { (unsigned int *)cltfactor_table,    (unsigned int *)cltfactor_table,    sizeof(cltfactor_table) }, 
    { (unsigned int *)matfactor_table,    (unsigned int *)matfactor_table,    sizeof(matfactor_table) }, 
    { (unsigned int *)egofactor_table,    (unsigned int *)egofactor_table,    sizeof(egofactor_table) }, 
    { (unsigned int *)maffactor_table,    (unsigned int *)maffactor_table,    sizeof(maffactor_table) }, 
    { (unsigned int *)&ram_data,          (unsigned int *)&flash4,            1024                    }, 
    { (unsigned int *)&ram_data,          (unsigned int *)&flash5,            1024                    },
    { (unsigned int *)&canbuf,            NULL,                               sizeof(canbuf)          },
    { (unsigned int *)&outpc,             NULL,                               sizeof(outpc)           },
    { (unsigned int *)&ram_data,          (unsigned int *)&flash8,            1024                    },
    { (unsigned int *)&ram_data,          (unsigned int *)&flash9,            1024                    },
    { (unsigned int *)&ram_data,          (unsigned int *)&flash10,           1024                    },
    { (unsigned int *)&ram_data,          (unsigned int *)&flash11,           1024                    },
    { (unsigned int *)&ram_data,          (unsigned int *)&flash12,           1024                    },
    { NULL,                               NULL,                               0                       },
    { (unsigned int *)&Signature,         (unsigned int *)&Signature,         SIZE_OF_SIGNATURE + 3   },
    { (unsigned int *)&RevNum,            (unsigned int *)&RevNum,            SIZE_OF_REVNUM          }
};

// IAC stepper motor sequence
const unsigned char IACCoilA[8] = {0,0,1,1,0,0,1,1};
const unsigned char IACCoilB[8] = {1,0,0,1,1,0,0,1};

const unsigned int fuelcut_array[4][4] = // mapping of injs to cut vs. [num inj][cut num]
    {{ 0x01, 0x00, 0x00, 0x00 }, //  num_inj = 1
     { 0x01, 0x02, 0x00, 0x00 }, //  2
     { 0x01, 0x02, 0x04, 0x00 }, //  3
     { 0x01, 0x04, 0x02, 0x08 }};//  4

/* Convert MS2 counter to CAN broadcast"group number" */
const unsigned char can_outpc_ix[32] = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,
                            17,18,26,27,28,29,43,46,47,51,52,55,57,58,59,99};

const unsigned int can_outpc_int[8] = {7812,7812,3906,1562,781,391,156,156};

#include "ms2_extra_main_vars.h"

#endif

