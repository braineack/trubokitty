/* $Id: ms2_extra_main_defaults.h,v 1.42 2015/01/11 10:29:16 jsmcortina Exp $
 * Copyright 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013
 * James Murray and Kenneth Culver
 *
 * This file is a part of MS2/Extra.
 *
 * You should have received a copy of the code LICENSE along with this source,
 * ask on the www.msextra.com forum if you did not.
 *
 */

/*************************************************************************
 **************************************************************************
 **   M E G A S Q U I R T  II - 2 0 0 4 - V1.000
 **
 **   (C) 2003 - B. A. Bowling And A. C. Grippo
 **
 **   This header must appear on all derivatives of this code.
 **
 ***************************************************************************
 **************************************************************************/

/*************************************************************************
 **************************************************************************
 **   GCC Port
 **
 **   (C) 2004,2005 - Philip L Johnson
 **
 **   This header must appear on all derivatives of this code.
 **
 ***************************************************************************
 **************************************************************************/

/*************************************************************************
 **************************************************************************
 **   MS2/Extra
 **
 **   (C) 2006,2007,2008 - Ken Culver, James Murray (in either order)
 **
 **   This header must appear on all derivatives of this code.
 **
 ***************************************************************************
 **************************************************************************/

const page4_data flash4 EEPROM_ATTR = {
    4,               // no_cyl (1-12)   
    3,               // no_skip_pulses
    0x15,            // ICIgnOption,
#ifdef MICROSQUIRT
    0,                 // injctl2 (PWM limiting off)
#else
    3,                 // injctl2
#endif
    46, 15, 9,       // max_coil_dur,max_spk_dur,DurAcc   msx10
    {60,80,100,120,140,160},   // deltaV_table[], Vx10 = batt_voltx10 - 120
    {250,  124, 84,64,51,44},   // deltaDur_table[], %age correction for batt_volt. 50 = 100%
    // MS1/Extra uses these
    //dwelltv: db     51T,68T,85T,102T,119T,136T    ; 6v,8v,10v,12v,14v,16v
    //dwelltf: db     250T,124T,84T,64T,51T,44T
    //Values in table are /4 (i.e. 250 = 250/256*4 = x 3.9)

    2,           // PredOpt      (For EDIS PredOpt=0 is sufficient)
    // For EDIS keep total adv (incl. offset & cold adv) < 60 deg
    650,         // rpm at which cranking through
    {60,              // cold_adv_table[TEMP no = 0], deg x 10
        50,40,30,20,10,0,0,0,0},
    0,                // adv_offset,   deg x 10
    900, 200,       // TpsBypassCLTRevlim , RevLimRpm2
    {{{130,             // afr_table[inj1][MAP/tps no =0][RPM no = 0], afrx10
          135,160,160,160,149,143,132,131,132,131,130},
    {132,             // afr_table[inj1][MAP/tps no =1][RPM no = 0], afrx10
        137,157,157,155,149,142,132,130,129,128,127},
    {134,             // afr_table[inj1][MAP/tps no =2][RPM no = 0], afrx10
        139,155,155,154,149,141,130,129,128,127,127},
    {135,             // afr_table[inj1][MAP/tps no =3][RPM no = 0], afrx10
        140,152,152,150,147,140,130,129,128,127,126},
    {136,             // afr_table[inj1][MAP/tps no =4][RPM no = 0], afrx10
        141,150,149,147,147,140,129,128,127,126,126},
    {135,             // afr_table[inj1][MAP/tps no =5][RPM no = 0], afrx10
        138,145,143,141,141,135,128,127,126,126,126},
    {134,             // afr_table[inj1][MAP/tps no =6][RPM no = 0], afrx10
        134,139,137,136,136,131,127,126,126,126,126},
    {132,             // afr_table[inj1][MAP/tps no =7][RPM no = 0], afrx10
        132,135,133,133,132,130,126,125,125,125,125},
    {130,             // afr_table[inj1][MAP/tps no =8][RPM no = 0], afrx10
        130,131,130,130,129,130,125,125,125,125,125},
    {130,             // afr_table[inj1][MAP/tps no =9][RPM no = 0], afrx10
        129,129,128,128,127,126,125,125,125,125,124},
    {130,             // afr_table[inj1][MAP/tps no =10][RPM no = 0], afrx10
        129,129,128,128,127,126,125,125,125,123,123},
    {130,             // afr_table[inj1][MAP/tps no =11][RPM no = 0], afrx10
        129,129,128,128,127,126,125,125,122,122,122}},

    {{130,             // afr_table[inj2][MAP/tps no =0][RPM no = 0], afrx10
         135,160,160,160,149,143,132,131,132,131,130},
    {132,             // afr_table[inj2][MAP/tps no =1][RPM no = 0], afrx10
        137,157,157,155,149,142,132,130,129,128,127},
    {134,             // afr_table[inj2][MAP/tps no =2][RPM no = 0], afrx10
        139,155,155,154,149,141,130,129,128,127,127},
    {135,             // afr_table[inj2][MAP/tps no =3][RPM no = 0], afrx10
        140,152,152,150,147,140,130,129,128,127,126},
    {136,             // afr_table[inj2][MAP/tps no =4][RPM no = 0], afrx10
        141,150,149,147,147,140,129,128,127,126,126},
    {135,             // afr_table[inj2][MAP/tps no =5][RPM no = 0], afrx10
        138,145,143,141,141,135,128,127,126,126,126},
    {134,             // afr_table[inj2][MAP/tps no =6][RPM no = 0], afrx10
        134,139,137,136,136,131,127,126,126,126,126},
    {132,             // afr_table[inj2][MAP/tps no =7][RPM no = 0], afrx10
        132,135,133,133,132,130,126,125,125,125,125},
    {130,             // afr_table[inj2][MAP/tps no =8][RPM no = 0], afrx10
        130,131,130,130,129,130,125,125,125,125,125},
    {130,             // afr_table[inj2][MAP/tps no =9][RPM no = 0], afrx10
        129,129,128,128,127,126,125,125,125,125,124},
    {130,             // afr_table[inj2][MAP/tps no =10][RPM no = 0], afrx10
        129,129,128,128,127,126,125,125,125,123,123},
    {130,             // afr_table[inj2][MAP/tps no =11][RPM no = 0], afrx10
        129,129,128,128,127,126,125,125,122,122,122}}},

    {180,             // warmen_table[TEMP no = 0],   % enrichment vs temp
        180,160,150,135,125,113,108,102,100},
    {20,              // tpsen_table[TPS_DOT no = 0], enrichment in .1ms vs tpsdot
        50,105,150},
    {0,               // mapen_table[TPS_DOT no = 0], enrichment in .1ms vs mapdot
        0,0,0},
    {160,150,140,130,120,105,90,75,60,40}, //iacstep_table
    {{500,             // frpm_table1[RPM no = 0] , use in  AFR tables
         800,1100,1400,2000,2600,3100,3700,4300,4900,5400,6000},
    {500,             // frpm_table2[RPM no = 0] , use in AFR table
        800,1100,1400,2000,2600,3100,3700,4300,4900,5400,6000}},
    {{300,             // fmap_table[MAP/tps no = 0], kPa x 10 , use for AFR
         350,450,500,550,600,700,750,800,850,950,1000},
    {300,             // fmap_table2[MAP/tps no = 0], kPa x 10 , use for AFR
        350,450,500,550,600,700,750,800,850,950,1000}},
    {-400,            // temp_table[TEMP no = 0],  deg x 10
        -200,0,200,400,600,800,1000,1300,1600},
    {2100,              // tpsdot_table[TPS_DOT no =0],
        4000,8000,15400},   //    change in % x 10 per .1 sec
    {0,               // mapdot_table[TPS_DOT no =0],
        0,0,0},         //    change in kPa x 10 per .1 sec
    93,              // map0,         kPa x 10, value @ 0 ADC counts
    2609,            // mapmax,       kPa x 10, value @ max(1023) ADC counts
    0,               // clt0,         deg (C or F) x 10
    100,             // cltmult,      %
    0,               // mat0,         deg (C or F) x 10
    100,             // matmult,      %
    0,               // tps0,         adc counts
    1023,            // tpsmax,       adc counts
    1,               // batt0,        v x 10
    297,             // battmax,      v x 10
    0,               // ego0,         afr x 10
    100,             // egomult,      %
    93,              // baro0,        kPa x 10
    2609,            // baromax,      kPa x 10
//    147, -47,        // bcor0,bcormult  kpax10, slope
    0, 0,        // bcor0,bcormult  kpax10, slope - nullified, just use correction curve instead
    0,               // knock0,       v x 100
    500,             // knockmax,     v x 100
    20,              // Dtpred_Gain,  %
    50,70,25,        // PulseTol,     % tolerance for next input pulse timing during
    // cranking, after start/ warmup, normal running
    0,               // IdleCtl, idle: 0 = none
    3,              // IACtstep,  1 ms units (25 gives pulse freq of 400 Hz)
    5,               // IAC_tinitial_step
    1,               // IACminstep
    127,             // dwell duty%
    250,             // IACStart,  no. of steps to send at startup to put stepper
    //    motor at reference (wide open) position
    50,              // IdleHyst amount (degx10)
    100,5,           // > IAC opening (< steps) during cranking and few secs after
    1,              // current limiting
    {0,0,0,0,0}, // unused
    1000, // InjOpen
    //    0, // BatFac //***** testing
    1200, // BatFac
    0, //OverBoostOption
    1000, //OverBoostKpa
    100, //OverBoostHyst
    6, //overboostcutx
    7, //overboostcuty
    0, //secondtrigopts
    2000,             // TpsThresh, tpsdot threshhold for accel enrichment(change in %x10 per .1 s)
    100,             // MapThresh, mapdot threshhold for accel enrichment(change in kPax10 per .1 s)
    30,              // Tpsacold,  cold (-40F) accel amount in .1 ms units
    130,             // AccMult,   cold (-40F) accel multiply factor (%)
    400,             // mapsample_angle
    2,               // TpsAsync,  clock duration (in .1 sec tics) for accel enrichment
    100,              // TPSDQ,  deceleration fuel cut option (%)
    700,             // TPSWOT, TPS value at WOT (for flood clear), %x10
    700,             // TPSOXLimit,  Max tps value (%x10) where O2 closed loop active
    100,             // Tps_acc_wght, weight to be given to tpsdot for accel enrichment.
    //  100 - Tps_acc_wght will then be given to mapdot.
    0,               // BaroOption,  0=no baro, 1=baro is 1st reading of map (before cranking),
    //   2=independent barometer
    //    0,               // 0 = no ego;1= nb o2;2=2 nb o2;3=single wbo2;4=dual wbo2. //***** testing
    1,               // 0 = no ego;1= nb o2;2=2 nb o2;3=single wbo2;4=dual wbo2.
    16,              // EgoCountCmp,  Ign Pulse counts between when EGO corrections are made
    1,               // EgoStep,   % step change for EGO corrections
    15,              // EgoLimit,  Upper/Lower rail limit (egocorr inside 100 +/- limit)
    140,             // AFRTarget,  NBO2 afr (afrx10) determining rich/ lean
    0,               // Temp_Units,    0= coolant & mat in deg F; 1= deg C
    0,0x4,             // MAF options(future),cpad byte
    1400,            // FastIdle, fast idle temperature (degx10) (idle_ctl = 1 only)
    1600,            // EgoTemp,  min clt temp where ego active, degx10
    1300,            // RPMOXLimit,  Min rpm where O2 closed loop is active
    //    5000,           // ReqFuel;  fuel pulsewidth (usec) at wide open throttle //***** testing
    15500,           // ReqFuel;  fuel pulsewidth (usec) at wide open throttle
    2,               // Divider,   divide factor for input tach pulses  
    //    0,               // Simultaneaous,   option to alternate injector banks //***** testing
    1,               // Alternate,   option to alternate injector banks
    10,              //
    200,             // InjPWMTim,   Time (.128 ms units) after opening to start pwm
    66,              // InjPWMPd,    Injector PWM period (us)
    75,              // InjPWMDty,   Injector PWM duty cycle (%)
    12,
    0,               // EngStroke,  0 = 4 stroke,  1 = 2 stroke
    0,               // InjType,  0 = port injection,  1 = throttle body
    4,               // NoInj,    no. of injectors (1-12)       
    900,               // OddFire smaller angle between firings
    50,50,50,        // Lag filter coefficients (1-100%) for Rpm,Map,Tps,
    60,              // ego1,2
    50,80,           // Lag filter coefficients for other adc(clt,mat,batt), knock.
    50,               // mafLF
    0,               // dual table option
    1,               // fuel alpha-N, map blend option
    1,               // ign alpha-N, map blend option
    1,               // WBO2 AFR alpha-N, map blend option
    10,              // dwell time in 0.1ms
    500,              // trigger to return angle
    0x21,           // RevLimOption:0,none; 1,retard spk; 2,fuel cut + more (see ini)
    120,         // RevLimMaxRtd,   deg x 10
    8,66,50,1000,1200, // injector channel 2 parameters
    1,  // MAPport
    1050,800,1000, // baro upper, lower, default
    6000, //RevLimTPSbypassRPM
    100, // RevLimRtdAng
    6000, //RevLimNormal2
    625, //TC5_required_width
    150, //EgoLimit
    147, //stoich
    0, //enable_poll bit 0: enable ADC 0-3; bit 1: enable ADC 4-7; bit 2: enable PWM; bit 3: enable digital I/O ports
    {7,7,7,7}, //poll_tables[4] Remote table numbers for ADC 0-3, ADC 4-7, PWM and ports data defaults to I/O Extender tables
    {2,10,58,75}, //poll_offset[4] Offset in the table (ADC 0-3, ADC 4-7, PWM, ports). Defaults to I/O Extender offsets
    0, //ports_dir Direction of the 3 remote ports: 0=input, 1=output
    0, // Select which port will be used as generic spare port: 0: use MS ports; 1,2,3: Remote ports
    2000,
    24, // remotePWMfreq: Remote PWM clock frequency  (in MHz)
    128, // remotePWMprescale: Remote PWM clock prescale
    0, 0, 781, // can_bcast
    0, // feature7
    0, // maf_range
    800, // map_phase_thresh
    {0,1000}, // flex_pct
    0, // baseline eth% for backwards compat
    0,    // fuelSpkDel_default
    163,    // fuelCorr_default
    0,      // spare
    400, // boost tol
    900, // flexboosttps
    {1800,1800,1800,1800,600,600}, // oddfireangs
    {5,    // can_poll_id defaults to 5 and master for ADC 0-3 polling
    5,    // can_poll_id defaults to 5 and master for ADC 4-7 polling
    5,    // can_poll_id defaults to 5 and master for PWM polling
    5},    // can_poll_id defaults to 5 and master for digital I/O ports polling
    {0,0,0,0,0,0,0,0,0}, // 9 spares
    0, // hw_latency
    30, // ego_startdelay
    0x0d, //loadopts, enabled incl AFR
    115200,                   // baud rate
    900,          // MAPOXLimit, Max MAP value (kPax10) where O2 closed loop active
    1,0,            // board_type, mycan_id
    0,0,0,0,      // adjustments to timing and such. Won't work.
    10,
    1,    // can_poll= CAN master enable = on
    0,    // spare
    200,          // MAPOXMin , Min MAP value (kpa*10)  where 02 closed loop active  --- KG was spare took one 0 away below (753)
    {0},    // spares
    {0,0,0,0,0,0,0}, // spr_port
    {'>','>','>','>','>','>','>'}, // condition1
    {'>','>','>','>','>','>','>'}, // condition2
    {' ',' ',' ',' ',' ',' ',' '}, // cond12
    {0,0,0,0,0,0,0},
    {1,1,1,1,1,1,1},{0,0,0,0,0,0,0},{0,0,0,0,0,0,0},  {0,0,0,0,0,0,0},{0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},{0,0,0,0,0,0,0},{0,0,0,0,0,0,0},{0,0,0,0,0,0,0},  // spr pin params
    1,          // accel tail duration (sec x 10),
    0,          // primedelay
    20,           // accel end pwidth enrichment (ms x 10)
    0,            // EgoAlg, 0=simple algorithm; 1=Prop err alg;2=PID w. Smith pred
    100,20,0,      // KP,KI,KD, PID coefficients in %
    10,4000,      // egoKdly1,2 = coefficients used to calculate ego transport
    //   delay (ms) = Kdly1 + Kdly2*120000 / (map(kPax10)*rpm).
    //   Defaults based on xpt delay of .1 s at wot, 1 s at idle
    0,          // Flex fuel option - modifies pw and spk adv based on freq signal
    //  for % alcohol
    {50, 150},          // Table of fuel sensor freq(Hz) vs
    {100,163},    // fuelcor  fuel pw corr in %; 1st element is pure gasoline, 2nd is pure Alcohol.
    0, // dwell mode   "std dwell", "fixed duty", "time after spk", "chg at trigger"
    200,    // iacfullopen
    {0,0,0,0,0,0,0,0,0,0},
    0,         // spare
    0x00,    // knk_option: Bits 0-3: 0=no knock detection;1=operate at table value or 1
    // step below knock; 2=operate at table value or edge of knock.
    // Bits 4-7: 0/1 = knock signal < / > knk_thresh indicates knock occurred.
    100,     // knk_maxrtd, max total retard when knock, (degx10).
    30,10,   // knk_step1, _step2, ign retard/ adv steps when 1st knock or after stopped,
    // (degx10); step1 large to quickly retard/ stop knock
    2,20,    // knk_trtd,_tadv, time between knock retard, adv corrections, (secx10);
    // allows short time step to quickly retard, longer to try advancing.
    30,      // knk_dtble_adv, change in table advance required to restart adv til knock
    // or reach table value (0 knock retard) process, deg x10.
    // This only applies with knk_option = 1.
    2,     // knk_ndet, number of knock detects required for valid detection; pad byte.
    0,     //Xtau option
    700,     // knk_maxmap, no knock retard above this map (kPax10).
    700,3500,  // knk_lorpm,knk_hirpm,  no knock retard below, above these rpms.
    {500,       // knk_rpm[0-NO_KNKRPMS], tables of rpm vs knock threshhold.
        1000,
        2000,
        3000,
        4000,
        5000},
    {200,       //knk_thresh[NO_KNKRPMS], Vx100
        200,
        200,
        200,
        200,
        200},
    36,         // No_Teeth, nominal (include missing) teeth for wheel decoding. (0=
    // no wheel decoding).
    1,         // No_Miss_Teeth, number of consecutive missing teeth.
    0,         // Angle of missing tooth BTDC
    01,         // (0.1ms) ICISR_tmask, time (msx10) after tach input capture during which further
    // interrupts are inhibited to mask coil ring or VR noise.
    10,        // ICISR_pmask, % of dtpred after tach input capture during which further
    // interrupts are inhibited to mask coil ring or VR noise.
    0,         // spare
    2500, 5000, // ae_lorpm,ae_hirpm, lorpm is rpm at which normal accel enrichment just
    // starts to scale down, and is reduced to 0 at ae_hirpm. To omit scaling, set
    //  _lorpm = _hirpm= very large number.
    {0,35},  // ffSpkDel fuelSpkDel flex fuel spk corr (degx10); 1st element for pure gasoline, 2nd for pure
    // Alcohol; last is normally - to retard spk since Alch burns faster.
    2,20,    // cam input mask time and %age settings
    0,  // noise filter options
    0,     // spare
#ifdef MICROSQUIRT
    0,      // spk_config_spka use JS10 for spark A, crank wheel
#else
    1,      // spk_config_spka use D14 for spark A, crank wheel
#endif
    0,      // spk_conf2
    0x14,   // spk_config - paired oddfire, TFI non-signature
    4,      // spk_mode, "toothed wheel" and single coil
    0,      // spk_mode3
    6,      // rtbaroport
    6,      // ego2port
    0,      // egoport: 0 means local port; > 0 means remote CAN port
    1501,   // 1ms kick-start delay
    0,      // spare
    0,      // use simple false trig as should be working now
    {60, 54, 49, 44, 38, 32, 27, 21, 13, 5},  // pwm idle table
    2,90,100,100   // timing_flags, crank_dwell, crank_timing, fixed_timing
};

const page5_data flash5 EEPROM_ATTR = {
    {1500,1400,1300,1200,1100,1000,900,800}, // pwmidle_target_rpms
    {700,800,900,1000,1100,1200,1300,1400}, // pwmidle_clt_temps
    200, // pwmidle_ms
    3,  // pwmidle_close_delay
    153, // pwmidle_open_duty
    38, // pwmidle_closed_duty
    5, // pwmidle_pid_wait_timer
    20, // pwmidle_min_duty
    300, // pwmidle_engage_rpm_adder
    10, // pwmidle_tps_thresh
    3, // pwmidle_dp_adder
    10, // pwmidle_rpmdot_threshold
    250, // pwmidle_decelload_threshold
    1000, // pwmidle_Kp
    1000, // pwmidle_Ki
    0, // pwmidle_Kd
    2,
    0,
    500,
    2,
    100,
    0,  // pwmidle_port
    0,  // pwmidle_dp_decay_factor
    2000, // boost_ctl_sensitivity
    {0},
    0x04, 0x18, // boost_ctl_settings
    100, 100, 100, 0, 100, 10, // boost_ctl_Kp,Ki,Kd,boost_ctl_closeduty, boost_ctl_openduty,boost_ctl_ms
    {{1000,1000,1000,1000,1000,1000,1000,1000}, // boost_ctl_load_targets
        {1000,1000,1000,1000,1000,1000,1000,1000},
        {1000,1000,1000,1000,1000,1000,1000,1000},
        {1000,1000,1000,1000,1000,1000,1000,1000},
        {1000,1000,1000,1000,1000,1000,1000,1000},
        {1000,1000,1000,1000,1000,1000,1000,1000},
        {1000,1000,1000,1000,1000,1000,1000,1000},
        {1000,1000,1000,1000,1000,1000,1000,1000}},
    {0, 200, 400, 600, 700, 800, 900, 1000},   //boost_ctl_loadtarg_tps_bins
    {500, 1000, 2000, 3000, 4000, 5000, 6000, 7000},    //boost_ctl_loadtarg_rpm_bins
    {{0,0,0,0,0,0,0,0}, //boost_ctl_pwm_targets
        {0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0}},
    {0, 200, 400, 600, 700, 800, 900, 1000},   //boost_ctl_pwmtarg_tps_bins
    {500, 1000, 2000, 3000, 4000, 5000, 6000, 7000},    //boost_ctl_pwmtarg_rpm_bins
    {153,140,127,102}, //pwmidle_crank_dutyorsteps
    {300,1000,1300,1750}, //pwmidle_crank_clt_temps
    {{900,900,900,900,900,900},  // inj_adv_table3[0][0-5]      
        {900,900,900,900,900,900},  // inj_adv_table3[1][0-5]      
        {900,900,900,900,900,900},  // inj_adv_table3[2][0-5]      
        {900,900,900,900,900,900},  // inj_adv_table3[3][0-5]      
        {900,900,900,900,900,900},  // inj_adv_table3[4][0-5]      
        {900,900,900,900,900,900}}, // inj_adv_table3[5][0-5]      
    {800,2000,4000,5000,6000,7000},  //srpm_inj_adv3[0-5]; injection advance rpm tables     
    {300,500,700,800,900,1000},  // smap_inj_adv3[0-5]; kpa x 10,   
    { 60, 56, 52, 48, 44, 40, 36, 32, 26, 20},   // CWPrime, (msx10)
    {325, 300, 275, 250, 225, 200, 175, 150, 125, 100},   // CrankPctTable,   (%age)
    { 45, 43, 41, 39, 37, 35, 33, 31, 28, 25},   // CWAWEV,  %
    {350,330,310,290,270,250,230,210,180,150},   // CWAWC,   cycles
    {1600,1800,2000,2200,2400,2600},        // MatTemps, degx10 F or C
    {0,0,20,40,60,80},                      // MatSpkRtd, degx10 matretard
    {800,1000,1500,2000,2500,3000,3500,4000,4500,5000,5500,6000}, // AWCRPM
    {800,1000,1500,2000,2500,3000,3500,4000,4500,5000,5500,6000}, // SOCRPM
    {300,350,400,450,500,550,600,650,700,800,900,1000}, //AWCKPA
    {300,350,400,450,500,550,600,650,700,800,900,1000}, //SOCKPA
    {22,28,30,32,38,40,42,48,50,52,58,60}, //BAWC in 1% units
    {22,28,30,32,38,40,42,48,50,52,58,60}, //BSOC in 0.1% units
    {100,95,90,85,80,75,70,65,60,55,50,45}, //AWN
    {45,50,55,60,65,70,75,80,85,90,95,100}, //SWN
    {100,100,100,100,100,100,100,100,100,100,100,100}, // EAE
    {100,100,100,100,100,100,100,100,100,100,100,100},

    { 400, 600, 1000, 1300, 1600, 1800 },// MatVals[NO_MATS]: air temperatures (degx10) for air density correction table (old version)
    { 0, 0, 0, 0, 0, 0 }, // AirCorDel[NO_MATS], air density correction table(%) - added to eq. value (old version)
    200,
    {0,0,0,0,0,0,0,0,0,0}, // pad bytes
    {100,300,500,700,900,1100,1300,1500,1700,1800}, /* temp_table_p5 */
    6000,1000,800, // fuel table switch rpm, load, tps
    6001,1001,801, // spark table switch rpm, load, tps

    {0,200,400,600,800,1000,1200,1300,1400,1600,1700,1800},  // for EAE
    {0,200,400,600,800,1000,1200,1300,1400,1600,1700,1800},  // for EAE
    100, // airdensity scaling
#ifdef MICROSQUIRT
    0x11,  // ts_remote: Bit 0: Remote fuel table switching; Bit 1-3: Port3 Bit selection; Bit 4: Remote spark table switching; Bit 5-7: Port3 Bit selection
#else
    0,  // ts_remote: Bit 0: Remote fuel table switching; Bit 1-3: Port3 Bit selection; Bit 4: Remote spark table switching; Bit 5-7: Port3 Bit selection
#endif
    0,  // feature5_0 defaults to zero
    0,    // spare
    65, 5,    // cranking %, taper time
    0,        // pwm idle settings byte
    1500,     // fc >rpm
    400,      // fc <kpa
    50,       // fc <tps
    900,      // fc >clt
    15,       // fc >time
    0,        // no tacho out
    0,
    50,
    3000,
    0,
    1100,   // fc <rpm for recovery
    1500,
    3,
    {0,0,0,0,0,0,0,0,0,0},  // spare
    {0,0,0,0,0,0,0,0}, // spr_port
    {'<','<','<','<','<','<','<','<'}, // condition1
    {'<','<','<','<','<','<','<','<'}, // condition2
    {' ',' ',' ',' ',' ',' ',' ',' '}, // cond12
    {0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0},  {0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0}  // spr pin params
};


const page10_data flash10 EEPROM_ATTR = {

    //spark table 1
    {{{157,             // adv_table[MAP/tps no=0][RPM no=0], deg x 10
          175,200,286,328,375,370,375,380,380,380,380},
    {157,             // adv_table[MAP/tps no=1][RPM no=0], deg x 10
        178,201,282,324,370,370,370,375,380,380,380},
    {156,             // adv_table[MAP/tps no=2][RPM no=0], deg x 10
        180,202,278,324,368,370,375,375,380,380,380},
    {155,             // adv_table[MAP/tps no=3][RPM no=0], deg x 10
        182,204,274,323,364,370,370,375,375,380,380},
    {155,             // adv_table[MAP/tps no=4][RPM no=0], deg x 10
        184,206,272,322,360,368,374,374,376,376,380},
    {157,             // adv_table[MAP/tps no=5][RPM no=0], deg x 10
        186,207,268,321,360,366,372,375,375,375,375},
    {158,             // adv_table[MAP/tps no=6][RPM no=0], deg x 10
        188,208,258,320,360,365,365,365,370,370,370},
    {160,             // adv_table[MAP/tps no=7][RPM no=0], deg x 10
        185,205,250,317,358,360,362,362,362,362,362},
    {160,             // adv_table[MAP/tps no=8][RPM no=0], deg x 10
        183,203,241,308,353,360,360,360,360,360,360},
    {155,             // adv_table[MAP/tps no=9][RPM no=0], deg x 10
        175,200,235,299,348,360,360,360,360,360,360},
    {151,             // adv_table[MAP/tps no=10][RPM no=0], deg x 10
        172,195,228,295,343,360,360,360,360,360,360},
    {148,             // adv_table[MAP/tps no=11][RPM no=0], deg x 10
        168,190,216,282,335,360,360,360,360,360,360}},

    //spark table 2 - always additive so needs to be zero
    {{0,0,0,0,0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0,0,0,0,0}}},

    {{701,             // srpm_table1[RPM no = 0] , use in spark advance table
         900,1200,1500,2000,2600,3100,3700,4300,4900,5400,6000},
    {702,             // srpm_table2[RPM no = 0] , use in spark advance table
        900,1200,1500,2000,2600,3100,3700,4300,4900,5400,6000}},

    {{201,             // smap_table1[MAP/tps no = 0], kPa x 10 , use for spk adv
         250,300,350,400,450,500,600,700,800,900,1000},
    {202,             // smap_table2[MAP/tps no = 0], kPa x 10 , use for spk adv
        250,300,350,400,450,500,600,700,800,900,1000}},
    0, //spare
    0,200,10,4000,100,1,5,7,  // launch
    3000,4700,50,4800,         //flat shift
    217,550,0,0,0,0,0,0,           // staging
    1,3000,6000,800,1500,100,6000,3000,0,0,0, // nitrous
    5000,6000,10,50,3000,1500,

    /* user defined initial configuration data */
    0, 0, 0,
    /* end user defined */
    0, //staged_secondary_enrichment
    {{0, 0,  0, 0, 0, 0},
        {0, 5,  5,10,20,30},
        {0, 5, 10,20,30,40},
        {0,10, 20,30,40,50},
        {0,20,30,40,50, 60},
        {0,30,50,70,90,100}},
    {3000,4000,5000,5500,6000,7000},
    {500,600,700,800,900,1000},
    0, // Bit 0: remote input; Bit 1: remote outputs; Bits 2-4: remote input bit number on Port 3; Bits 5-7: remote ouputs bit number on Port 1 
    {0,0},
    30,
    {{0,0,0,0,0,0,0,0}, // rotary
        {0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0}},
    {300,400,500,600,700,800,900,1000},
    {800,1200,2000,3000,4000,5000,6000,7000},
    0,
    {500, 2500, 5500, 7500}, // NoiseFilterRpm
    {300,60,27,20}, // NoiseFilterLen - default values based on 15% of a 60-2 tooth
    0, // moved
    0, // staged_primary_delay

    {  3,10,20,50 }, //VariableLagTPSBins
    {  50,50,50,50 }, //VariableLagMapLags

    /*    {  0,0,0,0,0,0,0,0,
          0,0,0,0,0,0,0,0,
          0,0,0,0,0,0,0,0,
          0,0,0,0,0,0} normal 30 */
    { 0, 0,0,0,0, 0,0,0,0 }, // spare
    1, // tooth_init for injector sequencing
    0,
    {  0,0,0,0,0,0,0,  // the crap now 21
        0,0,0,0,0,0,0,0,
        0,0,0,0}
};

const page8_data flash8 EEPROM_ATTR = {
    // 1024 bytes = 1 block flash

    1, 25,
    0,  // no coils, no injectors
    30,1562, // 3.0ms 200ms interval
    0, // mode 0
    0, // zero pw
    0, // zero count

    //spark table 3
    {{157,             // adv_table[MAP/tps no=0][RPM no=0], deg x 10
         175,200,286,328,375,370,375,380,380,380,380},
    {157,             // adv_table[MAP/tps no=1][RPM no=0], deg x 10
        178,201,282,324,370,370,370,375,380,380,380},
    {156,             // adv_table[MAP/tps no=2][RPM no=0], deg x 10
        180,202,278,324,368,370,375,375,380,380,380},
    {155,             // adv_table[MAP/tps no=3][RPM no=0], deg x 10
        182,204,274,323,364,370,370,375,375,380,380},
    {155,             // adv_table[MAP/tps no=4][RPM no=0], deg x 10
        184,206,272,322,360,368,374,374,376,376,380},
    {157,             // adv_table[MAP/tps no=5][RPM no=0], deg x 10
        186,207,268,321,360,366,372,375,375,375,375},
    {158,             // adv_table[MAP/tps no=6][RPM no=0], deg x 10
        188,208,258,320,360,365,365,365,370,370,370},
    {160,             // adv_table[MAP/tps no=7][RPM no=0], deg x 10
        185,205,250,317,358,360,362,362,362,362,362},
    {160,             // adv_table[MAP/tps no=8][RPM no=0], deg x 10
        183,203,241,308,353,360,360,360,360,360,360},
    {155,             // adv_table[MAP/tps no=9][RPM no=0], deg x 10
        175,200,235,299,348,360,360,360,360,360,360},
    {151,             // adv_table[MAP/tps no=10][RPM no=0], deg x 10
        172,195,228,295,343,360,360,360,360,360,360},
    {148,             // adv_table[MAP/tps no=11][RPM no=0], deg x 10
        168,190,216,282,335,360,360,360,360,360,360}},

    {701,             // srpm_table3[RPM no = 0] , use in spark advance table
        900,1200,1500,2000,2600,3100,3700,4300,4900,5400,6000},
    {201,             // smap_table3[MAP/tps no = 0], kPa x 10 , use for spk adv
        250,300,350,400,450,500,600,700,800,900,1000},
    8,66,30,

    {320,680,1000,1200,1400,1600,1800,2000},                     // RevLimLookup
    {2500,3000,4000,4500,5000,5500,6000,6000},      // RevLimRpm1
    30, 250, // idle valve test settings
    0, // flashlock
    0, // idle_special_ops
    20, // idleadvance_tps
    1000, // idleadvance_rpm
    400, // idleadvance_load
    1400, // idleadvance_clt
    2, // idleadvance_delay

    {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},   // junk spare
    0, // feature413

    0, // crapalign      
    // Siamese and sequential injection     
    0, // seq_inj;          Bit 0: 1 = Sequential        
    // Bit 1: 1 = Siamese   
    // Bit 2: 1 = Extra injector drivers    
    // Bit 3: 0 = Single timing value; 1 = Dual timing values       
    // Bit 5: 0 = Fixed timing; 1 = Use table       
    // Bit 6,7: 0 = Start-of-pulse; 1 = Mid-pulse; 2 = End-of-pulse 
    {900,2700,900,900,2700,900},   // inj_adv_fixed[6]; Fixed injection advance: advance 1, advance 2, advance 3, staged advance 1, staged advance 2, staged advance 3       
    {{{900,900,900,900,900,900},  // inj_adv_table[0][0][0-5]        
         {900,900,900,900,900,900},  // inj_adv_table[0][1][0-5]        
         {900,900,900,900,900,900},  // inj_adv_table[0][2][0-5]        
         {900,900,900,900,900,900},  // inj_adv_table[0][3][0-5]        
         {900,900,900,900,900,900},  // inj_adv_table[0][4][0-5]        
         {900,900,900,900,900,900}}, // inj_adv_table[0][5][0-5]        
    {{2700,2700,2700,2700,2700,2700},  // inj_adv_table[1][0][0-5]  
        {2700,2700,2700,2700,2700,2700},  // inj_adv_table[1][1][0-5]  
        {2700,2700,2700,2700,2700,2700},  // inj_adv_table[1][2][0-5]  
        {2700,2700,2700,2700,2700,2700},  // inj_adv_table[1][3][0-5]  
        {2700,2700,2700,2700,2700,2700},  // inj_adv_table[1][4][0-5]  
        {2700,2700,2700,2700,2700,2700}}},// inj_adv_table[1][5][0-5]  
    {{800,2000,4000,5000,6000,7000},  //srpm_inj_adv[0][0-5]; injection advance rpm tables 
        {800,2000,4000,5000,6000,7000}}, //srpm_inj_adv[1][0-5]; injection advance rpm tables 
    {{300,500,700,800,900,1000},  // smap_inj_adv[0][0-5]; kpa x 10,       
        {300,500,700,800,900,1000}}, // smap_inj_adv[1][0-5]; kpa x 10,       
    {900,2700},   // inj_adv_crank[2]; Injection advance for cranking 1, 2
    15000, // hybrid_rpm
    100, // hybrid_hyst
    1000, // InjOpen3
    //              0, // BatFac3 //***** testing
    1200, // BatFac3
    1000, // InjOpen4
    //              0, // BatFac4 //***** testing
    1200, // BatFac4

    // ** VE TRIM 1 ** //
    {{{0,            // ve_trim1[MAP/tps no =0][RPM no = 0]
          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim1[MAP/tps no =1][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim1[MAP/tps no =2][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim1[MAP/tps no =3][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim1[MAP/tps no =4][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim1[MAP/tps no =5][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim1[MAP/tps no =6][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim1[MAP/tps no =7][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim1[MAP/tps no =8][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim1[MAP/tps no =9][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim1[MAP/tps no =10][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim1[MAP/tps no =11][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim1[MAP/tps no =12][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim1[MAP/tps no =13][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim1[MAP/tps no =14][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim1[MAP/tps no =15][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}}},

    {{501,             // frpm_tablev1[RPM no = 0] , use in VE   tables
         801,1101,1401,2001,2601,3101,3700,4300,4900,5400,6000,6500,7000,7200,7500}},
    {{301,             // fmap_tablev1[MAP/tps no = 0], kPa x 10 , use for VE
         350,400,450,500,550,600,650,700,750,800,850,900,950,980,1000}},

    1520, /* can_outpc_bcast */
    {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
   
    {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0, //0 16 spares
     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0, //1 16
     0,0}
    };

const page9_data flash9 EEPROM_ATTR = {
    {{{{26,            // ve_table[inj1][MAP/tps no =0][RPM no = 0]
           26,29,34,40,46,50,55,58,61,61,60,59,59,58,58},
    {29,              // ve_table[inj1][MAP/tps no =1][RPM no = 0]
        29,32,38,46,53,56,60,63,66,65,62,60,58,58,57},
    {38,              // ve_table[inj1][MAP/tps no =2][RPM no = 0]
        37,39,44,53,61,65,67,69,73,71,66,64,62,60,58},
    {43,              // ve_table[inj1][MAP/tps no =3][RPM no = 0]
        42,43,45,54,63,66,69,71,75,73,67,65,63,61,59},
    {48,              // ve_table[inj1][MAP/tps no =4][RPM no = 0]
        46,48,50,58,65,69,71,73,77,75,69,67,65,63,61},
    {52,              // ve_table[inj1][MAP/tps no =5][RPM no = 0]
        51,52,55,62,67,71,73,75,79,77,71,69,67,65,63},
    {57,              // ve_table[inj1][MAP/tps no =6][RPM no = 0]
        59,61,65,69,72,76,78,81,85,85,80,78,76,74,72},
    {61,              // ve_table[inj1][MAP/tps no =7][RPM no = 0]
        62,65,69,72,75,79,82,85,89,88,84,82,80,78,76},
    {65,              // ve_table[inj1][MAP/tps no =8][RPM no = 0]
        66,69,73,76,78,82,86,90,93,92,88,86,84,82,80},
    {68,              // ve_table[inj1][MAP/tps no =9][RPM no = 0]
        70,73,78,81,83,86,90,94,98,97,93,91,89,87,85},
    {72,              // ve_table[inj1][MAP/tps no =10][RPM no = 0]
        77,82,87,90,93,95,100,105,109,108,103,101,99,97,95},
    {74,              // ve_table[inj1][MAP/tps no =11][RPM no = 0]
        81,86,91,95,97,100,105,111,114,113,108,106,104,102,100},
    {74,              // ve_table[inj1][MAP/tps no =11][RPM no = 0]
        82,87,92,96,98,101,106,112,115,114,109,107,105,103,101},
    {75,              // ve_table[inj1][MAP/tps no =11][RPM no = 0]
        83,88,93,97,99,102,107,113,116,115,110,108,106,104,102},
    {76,              // ve_table[inj1][MAP/tps no =11][RPM no = 0]
        84,89,94,98,100,103,108,114,117,116,111,109,107,105,103},
    {78,              // ve_table[inj1][MAP/tps no =11][RPM no = 0]
        85,90,95,99,101,104,109,115,118,117,112,110,108,106,104}},

    // ** VE TABLE 2 ** //
    {{26,            // ve_table[inj1][MAP/tps no =0][RPM no = 0]
         26,29,34,40,46,50,55,58,61,61,60,59,59,58,58},
    {29,              // ve_table[inj1][MAP/tps no =1][RPM no = 0]
        29,32,38,46,53,56,60,63,66,65,62,60,58,58,57},
    {38,              // ve_table[inj1][MAP/tps no =2][RPM no = 0]
        37,39,44,53,61,65,67,69,73,71,66,64,62,60,58},
    {43,              // ve_table[inj1][MAP/tps no =3][RPM no = 0]
        42,43,45,54,63,66,69,71,75,73,67,65,63,61,59},
    {48,              // ve_table[inj1][MAP/tps no =4][RPM no = 0]
        46,48,50,58,65,69,71,73,77,75,69,67,65,63,61},
    {52,              // ve_table[inj1][MAP/tps no =5][RPM no = 0]
        51,52,55,62,67,71,73,75,79,77,71,69,67,65,63},
    {57,              // ve_table[inj1][MAP/tps no =6][RPM no = 0]
        59,61,65,69,72,76,78,81,85,85,80,78,76,74,72},
    {61,              // ve_table[inj1][MAP/tps no =7][RPM no = 0]
        62,65,69,72,75,79,82,85,89,88,84,82,80,78,76},
    {65,              // ve_table[inj1][MAP/tps no =8][RPM no = 0]
        66,69,73,76,78,82,86,90,93,92,88,86,84,82,80},
    {68,              // ve_table[inj1][MAP/tps no =9][RPM no = 0]
        70,73,78,81,83,86,90,94,98,97,93,91,89,87,85},
    {72,              // ve_table[inj1][MAP/tps no =10][RPM no = 0]
        77,82,87,90,93,95,100,105,109,108,103,101,99,97,95},
    {74,              // ve_table[inj1][MAP/tps no =11][RPM no = 0]
        81,86,91,95,97,100,105,111,114,113,108,106,104,102,100},
    {74,              // ve_table[inj1][MAP/tps no =11][RPM no = 0]
        82,87,92,96,98,101,106,112,115,114,109,107,105,103,101},
    {75,              // ve_table[inj1][MAP/tps no =11][RPM no = 0]
        83,88,93,97,99,102,107,113,116,115,110,108,106,104,102},
    {76,              // ve_table[inj1][MAP/tps no =11][RPM no = 0]
        84,89,94,98,100,103,108,114,117,116,111,109,107,105,103},
    {78,              // ve_table[inj1][MAP/tps no =11][RPM no = 0]
        85,90,95,99,101,104,109,115,118,117,112,110,108,106,104}},


    // ** VE TABLE 3 ** //
    {{26,            // ve_table[inj1][MAP/tps no =0][RPM no = 0]
         26,29,34,40,46,50,55,58,61,61,60,59,59,58,58},
    {29,              // ve_table[inj1][MAP/tps no =1][RPM no = 0]
        29,32,38,46,53,56,60,63,66,65,62,60,58,58,57},
    {38,              // ve_table[inj1][MAP/tps no =2][RPM no = 0]
        37,39,44,53,61,65,67,69,73,71,66,64,62,60,58},
    {43,              // ve_table[inj1][MAP/tps no =3][RPM no = 0]
        42,43,45,54,63,66,69,71,75,73,67,65,63,61,59},
    {48,              // ve_table[inj1][MAP/tps no =4][RPM no = 0]
        46,48,50,58,65,69,71,73,77,75,69,67,65,63,61},
    {52,              // ve_table[inj1][MAP/tps no =5][RPM no = 0]
        51,52,55,62,67,71,73,75,79,77,71,69,67,65,63},
    {57,              // ve_table[inj1][MAP/tps no =6][RPM no = 0]
        59,61,65,69,72,76,78,81,85,85,80,78,76,74,72},
    {61,              // ve_table[inj1][MAP/tps no =7][RPM no = 0]
        62,65,69,72,75,79,82,85,89,88,84,82,80,78,76},
    {65,              // ve_table[inj1][MAP/tps no =8][RPM no = 0]
        66,69,73,76,78,82,86,90,93,92,88,86,84,82,80},
    {68,              // ve_table[inj1][MAP/tps no =9][RPM no = 0]
        70,73,78,81,83,86,90,94,98,97,93,91,89,87,85},
    {72,              // ve_table[inj1][MAP/tps no =10][RPM no = 0]
        77,82,87,90,93,95,100,105,109,108,103,101,99,97,95},
    {74,              // ve_table[inj1][MAP/tps no =11][RPM no = 0]
        81,86,91,95,97,100,105,111,114,113,108,106,104,102,100},
    {74,              // ve_table[inj1][MAP/tps no =11][RPM no = 0]
        82,87,92,96,98,101,106,112,115,114,109,107,105,103,101},
    {75,              // ve_table[inj1][MAP/tps no =11][RPM no = 0]
        83,88,93,97,99,102,107,113,116,115,110,108,106,104,102},
    {76,              // ve_table[inj1][MAP/tps no =11][RPM no = 0]
        84,89,94,98,100,103,108,114,117,116,111,109,107,105,103},
    {78,              // ve_table[inj1][MAP/tps no =11][RPM no = 0]
        85,90,95,99,101,104,109,115,118,117,112,110,108,106,104}}}},


    {{{501,             // frpm_tablev1[RPM no = 0] , use in VE   tables
          801,1101,1401,2001,2601,3101,3700,4300,4900,5400,6000,6500,7000,7200,7500},
    {502,             // frpm_tablev2[RPM no = 0] , use in spark advance table
        801,1101,1401,2001,2601,3101,3700,4300,4900,5400,6000,6500,7000,7200,7500},
    {502,             // frpm_tablev3[RPM no = 0] , use in spark advance table
        801,1101,1401,2001,2601,3101,3700,4300,4900,5400,6000,6500,7000,7200,7500}}},
    {{{301,             // fmap_tablev1[MAP/tps no = 0], kPa x 10 , use for VE
          350,400,450,500,550,600,650,700,750,800,850,900,950,980,1000},
    {302,             // fmap_tablev2[MAP/tps no = 0], kPa x 10 , use for VE2
        350,400,450,500,550,600,650,700,750,800,850,900,950,980,1000},
    {302,             // fmap_tablev3[MAP/tps no = 0], kPa x 10 , use for VE2
        350,400,450,500,550,600,650,700,750,800,850,900,950,980,1000}}},
    {    // MAFFlow[NO_MAFS], MAF flows (mg/ secx10) for below corrections.
        100, 2000, 4000, 6000, 8000, 10000, 12000, 14000, 16000, 18000, 20000, 25000 }, 
    {    // MAFCor[NO_MAFS], Corrections to maf factor table (%) for real time tuning/ 
        100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100 },
    {0, 0, 0, 0, 0, 0},         // mat/clt vs flow correction
    {500, 1700, 2900, 4100, 5300, 6500}, // flow/100
    {0,0,0,0}
};

const page11_data flash11 EEPROM_ATTR = {
    // ** VE TRIM 2 ** //
    {{{{0,            // ve_trim[inj2][MAP/tps no =0][RPM no = 0]
           0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim[inj2][MAP/tps no =1][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim[inj2][MAP/tps no =2][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim[inj2][MAP/tps no =3][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim[inj2][MAP/tps no =4][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim[inj2][MAP/tps no =5][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim[inj2][MAP/tps no =6][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim[inj2][MAP/tps no =7][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim[inj2][MAP/tps no =8][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim[inj2][MAP/tps no =9][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim[inj2][MAP/tps no =10][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim[inj2][MAP/tps no =11][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim[inj2][MAP/tps no =12][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim[inj2][MAP/tps no =13][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim[inj2][MAP/tps no =14][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim[inj2][MAP/tps no =15][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}},

    // ** VE TRIM 3 ** //
    {{0,            // ve_trim[inj3][MAP/tps no =0][RPM no = 0]
         0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim[inj3][MAP/tps no =1][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim[inj3][MAP/tps no =2][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim[inj3][MAP/tps no =3][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim[inj3][MAP/tps no =4][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim[inj3][MAP/tps no =5][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim[inj3][MAP/tps no =6][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim[inj3][MAP/tps no =7][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim[inj3][MAP/tps no =8][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim[inj3][MAP/tps no =9][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim[inj3][MAP/tps no =10][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim[inj3][MAP/tps no =11][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim[inj3][MAP/tps no =12][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim[inj3][MAP/tps no =13][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim[inj3][MAP/tps no =14][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim[inj3][MAP/tps no =15][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}},


    // ** VE TRIM 4 ** //
    {{0,            // ve_trim[inj4][MAP/tps no =0][RPM no = 0]
         0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim[inj4][MAP/tps no =1][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim[inj4][MAP/tps no =2][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim[inj4][MAP/tps no =3][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim[inj4][MAP/tps no =4][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim[inj4][MAP/tps no =5][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim[inj4][MAP/tps no =6][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim[inj4][MAP/tps no =7][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim[inj4][MAP/tps no =8][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim[inj4][MAP/tps no =9][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim[inj4][MAP/tps no =10][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim[inj4][MAP/tps no =11][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim[inj4][MAP/tps no =12][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim[inj4][MAP/tps no =13][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim[inj4][MAP/tps no =14][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {0,              // ve_trim[inj4][MAP/tps no =15][RPM no = 0]
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}}}},


    {{{501,             // frpm_trimv2[RPM no = 0]
          801,1101,1401,2001,2601,3101,3700,4300,4900,5400,6000,6500,7000,7200,7500},
    {501,             // frpm_trimv3[RPM no = 0]
        801,1101,1401,2001,2601,3101,3700,4300,4900,5400,6000,6500,7000,7200,7500},
    {501,             // frpm_trimv4[RPM no = 0]
        801,1101,1401,2001,2601,3101,3700,4300,4900,5400,6000,6500,7000,7200,7500}}},
    {{{301,             // fmap_trimv1[MAP/tps no = 0], kPa x 10
          350,400,450,500,550,600,650,700,750,800,850,900,950,980,1000},
    {301,             // fmap_trimv3[MAP/tps no = 0], kPa x 10
        350,400,450,500,550,600,650,700,750,800,850,900,950,980,1000},
    {301,             // fmap_trimv4[MAP/tps no = 0], kPa x 10
        350,400,450,500,550,600,650,700,750,800,850,900,950,980,1000}}},
    {500, 500, 500, 500, 500, 500, 500, 500, 500, 500}, /* ITB_load_loadvals */
    {50, 77, 104, 158, 185, 236, 266, 293, 320, 347}, /* ITB_load_switchpoints */
    {800,1454,2109,3418,4072,5381,6036,6690,7345,8000}, /* ITB_load_rpms */
    {0,0,0,0}
};


const page12_data flash12 EEPROM_ATTR = {
    // idle enhancement section 
    0, // idle_up_options
    33, // idle_up_duty  
    0, // idle_up_targ_rpm
    200, // ac_idleup_delay
    0, // ClutchPIDEntry
    0, // pidrpm_window

    0x1f,  // ac_idleup_io_out
    0, // pwmidle_cl_opts;

    {150,150,150,150,150}, // idleadvance_curve
    {300,320,340,380,420}, // idleadvance_loads
    {600,800,925,1000,1100}, // idleadvance_rpms  

    {110,120,125,130,132,140}, // idle_voltage_comp_voltage  
    {0,0,0,0,0,0}, // idle_voltage_comp_delta  

    {800,900,1000,1100,1200}, // pwmidle_cl_initialvalue_rpms[5];        // 10
    {0,500,1000,1500,2120}, // pwmidle_cl_initialvalue_matorclt[5];    // 10
    {{70,80,90,100,110},
        {70,80,90,100,110},
        {70,80,90,100,110},
        {70,80,90,100,110},
        {70,80,90,100,110}}, // pwmidle_cl_initialvalues[5][5]; // 25
        0,
    /* MAF calib volts *1000 mafflow */
    {0, 80, 160, 230, 310, 390, 470, 550,
     630, 700, 780, 860, 940, 1020, 1090, 1170,
     1250, 1330, 1410, 1490, 1560, 1640, 1720, 1800,
     1880, 1960, 2030, 2110, 2190, 2270, 2350, 2420,
     2500, 2580, 2660, 2740, 2820, 2890, 2970, 3050,
     3130, 3210, 3280, 3360, 3440, 3520, 3600, 3680,
     3750, 3830, 3910, 3990, 4070, 4140, 4220, 4300,
     4380, 4460, 4540, 4610, 4690, 4770, 4850, 4930},
    /* MAF calib flow in g/sec * 1000 */
    {0, 50, 100, 151, 202, 254, 307, 361,
     417, 477, 549, 632, 721, 813, 909, 1008,
     1102, 1193, 1292, 1426, 1616, 1865, 2101, 2276,
     2422, 2602, 2816, 3051, 3310, 3592, 3895, 4233,
     4630, 5049, 5427, 5805, 6215, 6649, 7099, 7565,
     8055, 8574, 9119, 9687, 10271, 10869, 11479, 12101,
     12737, 13387, 14053, 14739, 15451, 16195, 16978, 17790,
     18612, 19420, 20214, 21056, 22017, 23168, 24556, 26122},

    {650, 700, 750, 800, 850, 900, 950, 1000, 1050}, // BaroVals[NO_BARS]: barometric pressures, (kPa x 10)) for baro correction table
    {-400, -40, 320, 590, 860, 1130, 1400, 1940, 2480}, // MatVals[NO_MATS]: air temperatures (degx10) for air density correction table

    {1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000}, // baro correction barocor - zero adjustment, 100%
    {1257, 1158, 1073, 1017,  967,  921,  880,  807, 746}, // MAT correction aircor - exposes default calc

    {100,200,400,600,800,1000},     // tpswot_tps[0 - 5] (% x 10);
    {0,1000,2000,3000,4000,6000},  // tpswot_rpm[0 - 5]
    {500,1000,1500,2000,2500,3000,4000,5000,6000,7000}, // knock_rpms
    {500,500,500,500,500,500,500,500,500,500},              // knock_thresholds
    0, 1, 15, 0, // shift_cut, shift_cut_in, shift_cut_out, spare
    8000, 750, // shift_cut_rpm, shift_cut_tps
    10, 8,  // shift_cut_delay, shift_cut_time
    10, // shift_cut_soldelay
    50, // shift_cut_reshift
    300, // ac_idleup_min_rpm
    5, // ac_delay_since_last_on
    0,

    {{100,100,100,100,100,100,100,100}, /* boost_ctl_cl_pwm_targs1 */
     {100,100,100,100,100,100,100,100},
     {100,100,100,100,100,100,100,100},
     {100,100,100,100,100,100,100,100},
     {100,100,100,100,100,100,100,100},
     {100,100,100,100,100,100,100,100},
     {100,100,100,100,100,100,100,100},
     {100,100,100,100,100,100,100,100}},
    {1500, 2500, 3500, 4500, 5000, 5500, 6000, 6500}, /* boost_ctl_cl_pwm_rpms1 */
    {1000, 1100, 1300, 1400, 1500, 1600, 1700, 1800}, /* boost_ctl_cl_pwm_targboosts1 */
          
    1234, {4,0,0,0,0,0,0,0}, // can_bcast_user
    1512, 0x10, /* dashbcast */
     {0,0,0,0,0,0,0,0,0,0,0,0,0},        // 13 zeros - spare

    {{{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},  // 16 offsets; Message 1
      {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}}, // 16 sizes
     {{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},  // 16 offsets; Message 2
      {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}}, // 16 sizes
     {{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},  // 16 offsets; Message 3
      {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}}, // 16 sizes
     {{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},  // 16 offsets; Message 4
      {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}}, // 16 sizes
     {{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},  // 16 offsets; Message 5
      {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}}, // 16 sizes
     {{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},  // 16 offsets; Message 6
      {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}}, // 16 sizes
     {{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},  // 16 offsets; Message 7
      {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}}, // 16 sizes
     {{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},  // 16 offsets; Message 8
      {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}}} // 16 sizes
};

